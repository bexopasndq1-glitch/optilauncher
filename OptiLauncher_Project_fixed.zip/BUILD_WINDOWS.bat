@echo off
setlocal
cd /d "%~dp0"
title OptiLauncher - automatic Windows setup and build

where powershell.exe >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Windows PowerShell was not found.
  echo This script requires Windows 10/11 with Windows PowerShell 5.1.
  pause
  exit /b 1
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD_WINDOWS.ps1"
set "RESULT=%ERRORLEVEL%"
if not "%RESULT%"=="0" (
  echo.
  echo [ERROR] Setup or build failed. Read the error message above.
)
echo.
pause
exit /b %RESULT%
