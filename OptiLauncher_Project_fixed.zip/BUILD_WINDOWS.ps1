$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectRoot

function Write-Section([string]$Message) {
    Write-Host ''
    Write-Host ('=' * 62) -ForegroundColor DarkCyan
    Write-Host " $Message" -ForegroundColor Cyan
    Write-Host ('=' * 62) -ForegroundColor DarkCyan
}

function Test-Admin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Refresh-ProcessPath {
    $machinePath = [Environment]::GetEnvironmentVariable('Path', 'Machine')
    $userPath = [Environment]::GetEnvironmentVariable('Path', 'User')
    $extra = @(
        (Join-Path $env:USERPROFILE '.cargo\bin'),
        (Join-Path $env:ProgramFiles 'nodejs')
    )
    $env:Path = (($extra + @($userPath, $machinePath, $env:Path)) | Where-Object { $_ } | Select-Object -Unique) -join ';'
}

function Start-InstallerProcess {
    param(
        [Parameter(Mandatory = $true)][string]$FilePath,
        [Parameter(Mandatory = $true)][string[]]$ArgumentList,
        [switch]$Elevate
    )

    if ($Elevate -and -not (Test-Admin)) {
        return (Start-Process -FilePath $FilePath -ArgumentList $ArgumentList -Wait -PassThru -Verb RunAs)
    }
    return (Start-Process -FilePath $FilePath -ArgumentList $ArgumentList -Wait -PassThru)
}

function Install-NodeLts {
    Write-Host '[SETUP] Node.js 20+ / npm not found. Downloading the official Node.js LTS installer...' -ForegroundColor Yellow
    $archToken = if ([Environment]::Is64BitOperatingSystem) { 'x64' } else { 'x86' }
    if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64' -or $env:PROCESSOR_ARCHITEW6432 -eq 'ARM64') {
        $archToken = 'arm64'
    }
    $fileKey = switch ($archToken) {
        'arm64' { 'win-arm64-msi' }
        'x86'   { 'win-x86-msi' }
        default { 'win-x64-msi' }
    }

    $releases = Invoke-RestMethod -Uri 'https://nodejs.org/dist/index.json'
    $release = $releases | Where-Object { $_.lts -and $_.files -contains $fileKey } | Select-Object -First 1
    if (-not $release) { throw 'Could not find an official Node.js LTS MSI for this Windows architecture.' }

    $msiName = "node-$($release.version)-$archToken.msi"
    $downloadUrl = "https://nodejs.org/dist/$($release.version)/$msiName"
    $checksumUrl = "https://nodejs.org/dist/$($release.version)/SHASUMS256.txt"
    $msiPath = Join-Path $env:TEMP $msiName

    Invoke-WebRequest -Uri $downloadUrl -OutFile $msiPath -UseBasicParsing
    $checksums = (Invoke-WebRequest -Uri $checksumUrl -UseBasicParsing).Content
    $checksumLine = $checksums -split "`r?`n" | Where-Object { $_ -match "\s$([regex]::Escape($msiName))$" } | Select-Object -First 1
    if (-not $checksumLine) { throw 'Could not find the Node.js MSI checksum; refusing to install an unverified download.' }
    $expectedHash = ($checksumLine -split '\s+')[0].ToLowerInvariant()
    $actualHash = (Get-FileHash -Path $msiPath -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actualHash -ne $expectedHash) { throw 'Node.js installer SHA-256 checksum did not match. The installer will not be run.' }

    Write-Host "[SETUP] Installing Node.js $($release.version). Windows may show a UAC confirmation." -ForegroundColor Yellow
    $msiArgs = @('/i', ('"' + $msiPath + '"'), '/qn', '/norestart')
    $process = Start-InstallerProcess -FilePath (Join-Path $env:SystemRoot 'System32\msiexec.exe') -ArgumentList $msiArgs -Elevate
    if ($process.ExitCode -notin @(0, 3010)) {
        throw "Node.js installer failed with exit code $($process.ExitCode)."
    }
    if ($process.ExitCode -eq 3010) {
        Write-Warning 'Windows reports that a restart may be required after installation.'
    }
    Refresh-ProcessPath
}

function Ensure-Node {
    $nodeMajor = 0
    $nodeCommand = Get-Command node -ErrorAction SilentlyContinue
    $npmCommand = Get-Command npm -ErrorAction SilentlyContinue
    if ($nodeCommand) {
        $nodeVersion = (& node --version 2>$null | Select-Object -First 1)
        if ($nodeVersion -match '^v?(\d+)') { $nodeMajor = [int]$Matches[1] }
    }
    if ($nodeMajor -lt 20 -or -not $npmCommand) {
        Install-NodeLts
    }
    Refresh-ProcessPath
    if (-not (Get-Command node -ErrorAction SilentlyContinue) -or -not (Get-Command npm -ErrorAction SilentlyContinue)) {
        throw 'Node.js/npm could not be found after installation. Close terminals and run BUILD_WINDOWS.bat again.'
    }
    $ver = (& node --version).Trim()
    if ($ver -match '^v?(\d+)') {
        $installedMajor = [int]$Matches[1]
        if ($installedMajor -lt 20) { throw "Node.js 20 or newer is required. Detected $ver." }
    }
    Write-Host "[OK] Node.js $ver and npm are available." -ForegroundColor Green
}

function Get-RustTarget {
    if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64' -or $env:PROCESSOR_ARCHITEW6432 -eq 'ARM64') {
        return 'aarch64-pc-windows-msvc'
    }
    if (-not [Environment]::Is64BitOperatingSystem) {
        return 'i686-pc-windows-msvc'
    }
    return 'x86_64-pc-windows-msvc'
}

function Install-Rustup {
    param([string]$Target)
    Write-Host '[SETUP] Rust/Cargo with the MSVC toolchain not found. Downloading rustup from the official Rust servers...' -ForegroundColor Yellow
    $rustupUrl = "https://static.rust-lang.org/rustup/dist/$Target/rustup-init.exe"
    $rustupExe = Join-Path $env:TEMP "rustup-init-$Target.exe"
    Invoke-WebRequest -Uri $rustupUrl -OutFile $rustupExe -UseBasicParsing

    $arguments = @('-y', '--default-host', $Target, '--default-toolchain', 'stable', '--profile', 'minimal')
    $process = Start-InstallerProcess -FilePath $rustupExe -ArgumentList $arguments
    if ($process.ExitCode -ne 0) { throw "Rustup installer failed with exit code $($process.ExitCode)." }
    Refresh-ProcessPath
}

function Ensure-Rust {
    $target = Get-RustTarget
    $rustcCommand = Get-Command rustc -ErrorAction SilentlyContinue
    $cargoCommand = Get-Command cargo -ErrorAction SilentlyContinue
    $rustupCommand = Get-Command rustup -ErrorAction SilentlyContinue
    $correctHost = $false

    if ($rustcCommand -and $cargoCommand) {
        $rustInfo = (& rustc -vV 2>$null | Out-String)
        $correctHost = $rustInfo -match [regex]::Escape("host: $target")
    }

    if (-not $cargoCommand -or -not $rustcCommand -or (-not $correctHost -and -not $rustupCommand)) {
        Install-Rustup -Target $target
    }

    Refresh-ProcessPath
    $rustupCommand = Get-Command rustup -ErrorAction SilentlyContinue
    if ($rustupCommand) {
        Write-Host '[SETUP] Selecting the stable MSVC Rust toolchain...' -ForegroundColor Yellow
        & rustup default "stable-$target"
        if ($LASTEXITCODE -ne 0) { throw 'Could not select the stable MSVC Rust toolchain.' }
    }

    Refresh-ProcessPath
    if (-not (Get-Command cargo -ErrorAction SilentlyContinue) -or -not (Get-Command rustc -ErrorAction SilentlyContinue)) {
        throw 'Rust/Cargo could not be found after installation. Restart Windows or run BUILD_WINDOWS.bat again.'
    }
    $cargoVersion = (& cargo --version).Trim()
    $rustcVersion = (& rustc --version).Trim()
    Write-Host "[OK] $cargoVersion; $rustcVersion" -ForegroundColor Green
}

function Test-VisualCppBuildTools {
    $vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
    if (-not (Test-Path $vswhere)) { return $false }
    $installation = & $vswhere -latest -products '*' -requires 'Microsoft.VisualStudio.Component.VC.Tools.x86.x64' -property installationPath 2>$null
    return [bool]($installation -and (Test-Path $installation.Trim()))
}

function Ensure-VisualCppBuildTools {
    if (Test-VisualCppBuildTools) {
        Write-Host '[OK] Visual Studio C++ Build Tools are available.' -ForegroundColor Green
        return
    }

    Write-Host ''
    Write-Host 'Tauri also needs Microsoft C++ Build Tools (Desktop development with C++).' -ForegroundColor Yellow
    Write-Host 'This extra dependency can download several gigabytes.' -ForegroundColor Yellow
    $answer = Read-Host 'Download and install them automatically now? [Y/N]'
    if ($answer -notmatch '^(Y|YES|Д|ДА)$') {
        throw 'C++ Build Tools are required. Run BUILD_WINDOWS.bat again and answer Y, or install the Visual Studio C++ Build Tools manually.'
    }

    $bootstrapper = Join-Path $env:TEMP 'vs_BuildTools.exe'
    Write-Host '[SETUP] Downloading the official Microsoft Visual Studio Build Tools installer...' -ForegroundColor Yellow
    Invoke-WebRequest -Uri 'https://aka.ms/vs/17/release/vs_BuildTools.exe' -OutFile $bootstrapper -UseBasicParsing
    $signature = Get-AuthenticodeSignature -FilePath $bootstrapper
    if ($signature.Status -ne 'Valid' -or -not $signature.SignerCertificate.Subject.Contains('Microsoft')) {
        throw 'The Microsoft Build Tools installer signature could not be verified. Refusing to run it.'
    }

    $arguments = @('--wait', '--passive', '--norestart', '--add', 'Microsoft.VisualStudio.Workload.VCTools', '--includeRecommended')
    $process = Start-InstallerProcess -FilePath $bootstrapper -ArgumentList $arguments -Elevate
    if ($process.ExitCode -notin @(0, 3010)) {
        throw "Visual Studio Build Tools installer returned exit code $($process.ExitCode)."
    }
    if (-not (Test-VisualCppBuildTools)) {
        throw 'The installer did not report a usable C++ toolchain. Restart the computer if requested, then run BUILD_WINDOWS.bat again.'
    }
    Write-Host '[OK] Visual Studio C++ Build Tools are installed.' -ForegroundColor Green
}


function Configure-MicrosoftSignIn {
    $idFile = Join-Path $ProjectRoot 'src-tauri\microsoft-client-id.txt'

    if ([string]::IsNullOrWhiteSpace($env:OPTILAUNCHER_MS_CLIENT_ID) -and (Test-Path $idFile)) {
        $env:OPTILAUNCHER_MS_CLIENT_ID = (Get-Content -Raw -Path $idFile).Trim()
    }

    if ([string]::IsNullOrWhiteSpace($env:OPTILAUNCHER_MS_CLIENT_ID)) {
        Write-Host ''
        Write-Host 'One-time publisher setup for Microsoft sign-in.' -ForegroundColor Yellow
        Write-Host 'Players will only see the normal Microsoft sign-in page.' -ForegroundColor Yellow
        Write-Host 'Paste the Application (client) ID of your public desktop app.' -ForegroundColor Yellow
        Write-Host 'Leave blank to build now without Microsoft sign-in.' -ForegroundColor Yellow
        $enteredId = Read-Host 'Microsoft Application (client) ID'
        if (-not [string]::IsNullOrWhiteSpace($enteredId)) {
            $env:OPTILAUNCHER_MS_CLIENT_ID = $enteredId.Trim()
        }
    }

    if (-not [string]::IsNullOrWhiteSpace($env:OPTILAUNCHER_MS_CLIENT_ID)) {
        $clientId = $env:OPTILAUNCHER_MS_CLIENT_ID.Trim()
        if ($clientId -notmatch '^[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}$') {
            throw 'The Microsoft Application (client) ID is not a valid GUID.'
        }
        $env:OPTILAUNCHER_MS_CLIENT_ID = $clientId
        # Client IDs are public identifiers, not secrets. Save locally so the next build won't ask again.
        [System.IO.File]::WriteAllText($idFile, $clientId + [Environment]::NewLine, [System.Text.UTF8Encoding]::new($false))
        Write-Host '[OK] Microsoft sign-in is configured; the ID is saved for future builds.' -ForegroundColor Green
    } else {
        Write-Warning 'No app ID was provided. The launcher will build, but Microsoft sign-in will remain unavailable until a publisher configures an app ID.'
    }
}

try {
    Write-Section 'OptiLauncher - automatic setup and Windows build'
    Write-Host "Project: $ProjectRoot"
    Write-Host 'Missing Node.js and Rust/Cargo will be downloaded from their official servers.'
    Write-Host 'Node.js downloads are verified against the official SHA-256 checksum file.'

    Write-Section '0/5 - Microsoft sign-in configuration'
    Configure-MicrosoftSignIn

    Write-Section '1/5 - Checking Node.js and npm'
    Ensure-Node

    Write-Section '2/5 - Checking Rust and Cargo'
    Ensure-Rust

    Write-Section '3/5 - Checking the native Windows build toolchain'
    Ensure-VisualCppBuildTools

    Write-Section '4/5 - Installing project dependencies'
    & npm install
    if ($LASTEXITCODE -ne 0) { throw "npm install failed with exit code $LASTEXITCODE." }

    Write-Section '5/5 - Building OptiLauncher'
    & npm run tauri build
    if ($LASTEXITCODE -ne 0) { throw "Tauri build failed with exit code $LASTEXITCODE. Review the compiler output above." }

    Write-Section 'BUILD FINISHED'
    Write-Host 'Look for the generated installer under:' -ForegroundColor Green
    Write-Host (Join-Path $ProjectRoot 'src-tauri\target\release\bundle') -ForegroundColor Green
    Write-Host 'If Windows requested a restart during setup, restart and run this script again if the build did not start.' -ForegroundColor Yellow
    exit 0
}
catch {
    Write-Host ''
    Write-Host "[ERROR] $($_.Exception.Message)" -ForegroundColor Red
    Write-Host ''
    Write-Host 'Nothing was deleted. Fix the reported problem and run BUILD_WINDOWS.bat again.' -ForegroundColor Yellow
    exit 1
}
