# OptiLauncher 0.3.0

OptiLauncher is a third-party Minecraft Java Edition launcher built with Tauri 2, React, TypeScript and Rust. It is not affiliated with Mojang or Microsoft.

## What is included

- Classic dark launcher interface with a green Play button.
- Minecraft version picker and Vanilla / Fabric / Forge selection beside Play.
- Local offline profiles. Offline profiles can only join servers that allow offline-mode authentication.
- Microsoft sign-in through the system browser using OAuth Authorization Code + PKCE. The app listens temporarily on loopback and resumes automatically after successful login.
- Minecraft Java profile validation after Microsoft sign-in. When Minecraft Services reports no Java profile (404), the app displays a friendly message explaining that the account may lack Java Edition / Game Pass access or a Java profile may not be set up yet.
- Modrinth search and single-mod JAR installation for the chosen Minecraft version and loader.
- Memory, resolution, logs, and version management.

## Build on Windows

1. Extract the ZIP to a normal writable folder.
2. Run `BUILD_WINDOWS.bat`. It checks Node.js/npm, Rust/Cargo and Visual Studio C++ Build Tools, offering to install missing prerequisites.
3. Microsoft sign-in is preconfigured with the Application (client) ID in `src-tauri/microsoft-client-id.txt`; the Windows build script reads it and compiles it into the launcher. You do not need to paste the ID when building or in the player-facing UI.
4. Wait for `BUILD FINISHED`. The installer is normally under `src-tauri/target/release/bundle/nsis/` or `src-tauri/target/release/bundle/msi/`.

For a different Microsoft app registration, replace the value in `src-tauri/microsoft-client-id.txt` or set `OPTILAUNCHER_MS_CLIENT_ID` before running `BUILD_WINDOWS.bat`. A client ID is a public identifier, not a password. Never place a client secret in the project.

## Microsoft sign-in setup (one-time publisher configuration)

The configured OAuth client ID must refer to a public/native desktop application that supports personal Microsoft accounts. The client ID is prefilled in this project; if Microsoft rejects it, check that registration and redirect settings are correct. Configure the `http://localhost` redirect for the **Mobile and desktop applications** platform. The app uses the Microsoft system login page and does not collect the Microsoft password itself. Follow Microsoft’s official Authorization Code + PKCE guide: https://learn.microsoft.com/en-us/entra/identity-platform/v2-oauth2-auth-code-flow

The player-facing window does not show registration instructions or ask players to paste an app ID. If the build was made without an ID, the login action displays a straightforward configuration message.

## Troubleshooting Microsoft login: HTTP 403

If the login error says `Invalid app registration`, Microsoft OAuth and Xbox/XSTS may have succeeded, but Minecraft Services is refusing the launcher application’s Client ID. This is a server-side application authorization restriction, not the player’s Minecraft licence status and not something fixed by changing a password or redirect URI. Follow the official Minecraft support guidance and request approval for your own Client ID: https://help.minecraft.net/hc/en-us/articles/16254801392141. The launcher now reads and displays the Minecraft Services error body instead of reducing every failure to a generic `403 Forbidden`. Never substitute another launcher’s Client ID.

## Current limitations

- Microsoft sign-in and the native Rust build have not been compiled or tested end-to-end in this environment. npm dependency installation timed out here, and Rust/Cargo are unavailable.
- Mod installation downloads individual JARs into the launcher profile. Automatic dependency resolution and full `.mrpack` modpack import/export are not implemented.
- The Java profile endpoint may return 404 when a Java profile is missing; the message also directs users to verify Game Pass access in the official launcher. The app does not attempt to bypass account/licensing checks.
- Fabric/Forge installer availability depends on the selected Minecraft version and the provider’s current metadata.
- Skin page currently stores a local preview only; it does not upload a skin to the account.

## Data and security

Refresh tokens are stored in the operating system credential store. Access tokens are kept in memory and are not written to logs. Microsoft passwords are entered only on the Microsoft-hosted browser page. OAuth uses PKCE and a random `state` value to validate the callback.
