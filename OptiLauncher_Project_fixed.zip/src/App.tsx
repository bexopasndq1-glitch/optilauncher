import { useCallback, useEffect, useMemo, useState } from "react";
import { invoke } from "@tauri-apps/api/core";
import { listen, type UnlistenFn } from "@tauri-apps/api/event";
import {
  Activity, AlertCircle, ArrowDownToLine, Blocks, Check, ChevronDown,
  Download, ExternalLink, FileText, Gamepad2, HardDrive, Image as ImageIcon,
  Info, Laptop, Layers3, LoaderCircle, MemoryStick, Play,
  Plus, RefreshCw, Search, Settings2, ShieldCheck, Sparkles, Trash2,
  UserRound, Users, X, Zap,
} from "lucide-react";

type Profile = { id: string; name: string; uuid: string; kind: string; clientId?: string | null };
type Settings = {
  ramGb: number;
  minRamGb: number;
  resolutionWidth: number;
  resolutionHeight: number;
  selectedVersion: string;
  javaPath: string;
  theme: string;
  selectedLoader: string;
  microsoftClientId: string;
};
type Version = { id: string; type: string; releaseTime?: string; url?: string; sha1?: string };
type Progress = { done: number; total: number; label?: string };
type ModResult = { project_id?: string; slug?: string; title?: string; description?: string; author?: string; downloads?: number; icon_url?: string };
type Screen = "home" | "versions" | "mods" | "skins" | "settings" | "logs";

const DEFAULT_SETTINGS: Settings = {
  ramGb: 4, minRamGb: 1, resolutionWidth: 1280, resolutionHeight: 720,
  selectedVersion: "", javaPath: "", theme: "dark", selectedLoader: "vanilla", microsoftClientId: "",
};
const DEMO_VERSIONS: Version[] = [
  { id: "1.21.11", type: "release", releaseTime: "2025-12-09T00:00:00+00:00" },
  { id: "1.21.10", type: "release", releaseTime: "2025-10-07T00:00:00+00:00" },
  { id: "1.20.6", type: "release", releaseTime: "2024-04-29T00:00:00+00:00" },
  { id: "1.8.9", type: "release", releaseTime: "2015-12-09T00:00:00+00:00" },
  { id: "24w14potato", type: "snapshot", releaseTime: "2024-04-01T00:00:00+00:00" },
];

function desktopAvailable() {
  return typeof window !== "undefined" && "__TAURI_INTERNALS__" in window;
}

function prettyDate(value?: string) {
  if (!value) return "Официальный релиз";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return "Официальный релиз";
  return new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "short", year: "numeric" }).format(d);
}

function App() {
  const [screen, setScreen] = useState<Screen>("home");
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [versions, setVersions] = useState<Version[]>(DEMO_VERSIONS);
  const [selectedProfileId, setSelectedProfileId] = useState("");
  const [selectedVersion, setSelectedVersion] = useState("");
  const [profileName, setProfileName] = useState("");
  const [showAddProfile, setShowAddProfile] = useState(false);
  const [profileError, setProfileError] = useState("");
  const [microsoftLoginBusy, setMicrosoftLoginBusy] = useState(false);
  const [modQuery, setModQuery] = useState("");
  const [modResults, setModResults] = useState<ModResult[]>([]);
  const [modSearchBusy, setModSearchBusy] = useState(false);
  const [modInstallingId, setModInstallingId] = useState("");
  const [installedMods, setInstalledMods] = useState<{ fileName: string }[]>([]);
  const [modsNotice, setModsNotice] = useState("");
  const [versionQuery, setVersionQuery] = useState("");
  const [versionFilter, setVersionFilter] = useState("all");
  const [settingsSaved, setSettingsSaved] = useState(false);
  const [loadingManifest, setLoadingManifest] = useState(false);
  const [launching, setLaunching] = useState(false);
  const [progress, setProgress] = useState<Progress>({ done: 0, total: 0, label: "" });
  const [phase, setPhase] = useState("");
  const [logs, setLogs] = useState<string[]>(["OptiLauncher запущен.", "Ожидание действий пользователя…"]);
  const [error, setError] = useState("");
  const [skinName, setSkinName] = useState("");
  const [skinData, setSkinData] = useState("");
  const [skinMessage, setSkinMessage] = useState("");
  const isDesktop = desktopAvailable();

  const addLog = useCallback((line: string) => {
    const time = new Date().toLocaleTimeString("ru-RU", { hour12: false });
    setLogs((old) => [...old.slice(-399), `[${time}] ${line}`]);
  }, []);

  const loadManifest = useCallback(async (quiet = false) => {
    if (!quiet) setLoadingManifest(true);
    try {
      const data = await invoke<any>("get_manifest");
      const rows = (data.versions ?? []) as Version[];
      setVersions(rows);
      const latest = data.latest?.release || rows.find((v) => v.type === "release")?.id || "";
      setSelectedVersion((old) => old || settings.selectedVersion || latest);
      addLog(`Манифест Mojang обновлён: ${rows.length} версий.`);
    } catch (e) {
      if (isDesktop) {
        setError(`Не удалось получить список версий: ${String(e)}`);
        addLog(`Ошибка манифеста: ${String(e)}`);
      } else {
        setSelectedVersion((old) => old || "1.21.11");
      }
    } finally {
      setLoadingManifest(false);
    }
  }, [addLog, isDesktop, settings.selectedVersion]);

  useEffect(() => {
    const init = async () => {
      if (isDesktop) {
        try {
          const saved = await invoke<Settings>("get_settings");
          setSettings({ ...DEFAULT_SETTINGS, ...saved });
          setSelectedVersion(saved.selectedVersion || "");
        } catch (e) { addLog(`Настройки по умолчанию: ${String(e)}`); }
        try {
          const rows = await invoke<Profile[]>("list_profiles");
          setProfiles(rows);
          const selected = localStorage.getItem("optilauncher.profile") || "";
          setSelectedProfileId(rows.some((p) => p.id === selected) ? selected : (rows[0]?.id || ""));
        } catch (e) { addLog(`Не удалось загрузить профили: ${String(e)}`); }
      } else {
        try {
          const saved = localStorage.getItem("optilauncher.settings");
          if (saved) { const parsed = JSON.parse(saved); setSettings({ ...DEFAULT_SETTINGS, ...parsed }); }
          const stored = localStorage.getItem("optilauncher.profiles");
          if (stored) {
            const rows = JSON.parse(stored) as Profile[];
            setProfiles(rows);
            setSelectedProfileId(rows[0]?.id || "");
          }
          const skin = localStorage.getItem("optilauncher.skin");
          if (skin) {
            const parsed = JSON.parse(skin);
            setSkinName(parsed.name || ""); setSkinData(parsed.data || "");
          }
        } catch { /* ignore invalid preview cache */ }
      }
      await loadManifest(true);
    };
    void init();
  }, []);

  useEffect(() => {
    if (!isDesktop) return;
    let unlisteners: UnlistenFn[] = [];
    let alive = true;
    void (async () => {
      const handles = await Promise.all([
        listen<string>("launcher:log", (event) => addLog(event.payload)),
        listen<any>("launcher:phase", (event) => setPhase(event.payload.message || event.payload.phase || "")),
        listen<Progress>("launcher:progress", (event) => setProgress(event.payload)),
      ]);
      if (alive) unlisteners = handles;
      else handles.forEach((f) => f());
    })();
    return () => { alive = false; unlisteners.forEach((f) => f()); };
  }, [isDesktop, addLog]);

  useEffect(() => {
    if (!isDesktop) localStorage.setItem("optilauncher.profiles", JSON.stringify(profiles));
  }, [profiles, isDesktop]);
  useEffect(() => {
    if (selectedProfileId) localStorage.setItem("optilauncher.profile", selectedProfileId);
  }, [selectedProfileId]);


  const chooseVersion = (versionId: string) => {
    setSelectedVersion(versionId);
    const next = { ...settings, selectedVersion: versionId };
    setSettings(next);
    if (isDesktop) {
      void invoke("save_settings", { settings: next }).catch((e) => addLog(`Не удалось сохранить выбранную версию: ${String(e)}`));
    } else {
      localStorage.setItem("optilauncher.settings", JSON.stringify(next));
    }
  };

  const selectedProfile = profiles.find((p) => p.id === selectedProfileId);
  const filteredVersions = useMemo(() => versions.filter((v) => {
    const matchesText = v.id.toLowerCase().includes(versionQuery.toLowerCase());
    const matchesType = versionFilter === "all" || v.type === versionFilter;
    return matchesText && matchesType;
  }), [versions, versionQuery, versionFilter]);
  const progressPct = progress.total > 0 ? Math.min(100, Math.round((progress.done / progress.total) * 100)) : 0;

  const createProfile = async () => {
    setError(""); setProfileError("");
    try {
      const name = profileName.trim();
      if (!isDesktop) {
        if (!/^[A-Za-z0-9_]{3,16}$/.test(name)) throw new Error("Ник должен содержать 3–16 латинских букв, цифр или _.");
        if (profiles.some((p) => p.name.toLowerCase() === name.toLowerCase())) throw new Error("Такой профиль уже есть.");
        const profile: Profile = { id: crypto.randomUUID(), name, uuid: crypto.randomUUID(), kind: "offline" };
        setProfiles((old) => [...old, profile]); setSelectedProfileId(profile.id);
      } else {
        const profile = await invoke<Profile>("create_offline_profile", { name });
        setProfiles((old) => [...old, profile]); setSelectedProfileId(profile.id);
        addLog(`Создан офлайн-профиль ${profile.name}.`);
      }
      setProfileName(""); setShowAddProfile(false);
    } catch (e) { setError(String(e).replace(/^Error: /, "")); }
  };

  const removeProfile = async (profile: Profile) => {
    if (profiles.length <= 1) { setError("Нужно оставить хотя бы один профиль."); return; }
    try {
      if (isDesktop) await invoke("delete_profile", { profileId: profile.id });
      setProfiles((old) => old.filter((p) => p.id !== profile.id));
      if (selectedProfileId === profile.id) setSelectedProfileId(profiles.find((p) => p.id !== profile.id)?.id || "");
      addLog(`Профиль ${profile.name} удалён.`);
    } catch (e) { setError(String(e)); }
  };

  const saveSettings = async () => {
    setError("");
    try {
      if (settings.minRamGb >= settings.ramGb) throw new Error("Минимальная память должна быть меньше максимальной.");
      const value = { ...settings, selectedVersion };
      if (isDesktop) await invoke("save_settings", { settings: value });
      else localStorage.setItem("optilauncher.settings", JSON.stringify(value));
      setSettings(value); setSettingsSaved(true); addLog("Настройки сохранены.");
      window.setTimeout(() => setSettingsSaved(false), 2200);
    } catch (e) { setError(String(e).replace(/^Error: /, "")); }
  };

  const launch = async () => {
    setError("");
    if (!selectedProfile) { setError("Сначала создай или выбери профиль игрока."); return; }
    if (!selectedVersion) { setError("Не удалось определить версию игры. Обнови список версий."); return; }
    if (!isDesktop) { setError("Для установки и запуска Minecraft открой приложение OptiLauncher на компьютере. Сейчас запущен только предпросмотр интерфейса."); return; }
    setLaunching(true); setProgress({ done: 0, total: 0, label: "Подготовка" });
    addLog(`Подготовка запуска ${selectedVersion} · профиль ${selectedProfile.name}.`);
    try {
      await invoke("install_and_launch", { versionId: selectedVersion, profileId: selectedProfile.id, loaderType: settings.selectedLoader || "vanilla" });
    } catch (e) { setError(String(e).replace(/^Error: /, "")); }
    finally { setLaunching(false); setPhase(""); }
  };

  const microsoftLogin = async () => {
    setError(""); setProfileError("");
    const clientId = settings.microsoftClientId.trim();
    if (!isDesktop) { setProfileError("Для входа через Microsoft открой установленное приложение OptiLauncher."); return; }
    if (!clientId) { setProfileError("В этой сборке не настроен вход через Microsoft. Установи версию лаунчера, собранную с поддержкой входа."); return; }
    setMicrosoftLoginBusy(true);
    try {
      const nextSettings = { ...settings, microsoftClientId: clientId };
      await invoke("save_settings", { settings: nextSettings });
      setSettings(nextSettings);
      addLog("Открываем защищённую страницу входа Microsoft в браузере…");
      const profile = await invoke<Profile>("microsoft_login", { clientId });
      setProfiles((old) => [...old.filter((p) => p.uuid.toLowerCase() !== profile.uuid.toLowerCase()), profile]);
      setSelectedProfileId(profile.id);
      addLog(`Аккаунт Microsoft подключён: ${profile.name}.`);
      setShowAddProfile(false);
    } catch (e) {
      const message = String(e).replace(/^Error: /, "");
      setProfileError(message);
      addLog(`Ошибка входа Microsoft: ${message}`);
    } finally {
      setMicrosoftLoginBusy(false);
    }
  };

  const loadInstalledMods = useCallback(async () => {
    if (!isDesktop || !selectedProfileId) { setInstalledMods([]); return; }
    try { setInstalledMods(await invoke<{ fileName: string }[]>("list_installed_mods", { profileId: selectedProfileId })); }
    catch { setInstalledMods([]); }
  }, [isDesktop, selectedProfileId]);

  useEffect(() => { void loadInstalledMods(); }, [loadInstalledMods]);

  const searchMods = async () => {
    setModsNotice(""); setError("");
    if (!isDesktop) { setModsNotice("Открой desktop-приложение, чтобы искать и устанавливать моды."); return; }
    if (!selectedVersion) { setModsNotice("Сначала выбери версию Minecraft на главной."); return; }
    const loader = settings.selectedLoader || "vanilla";
    if (loader === "vanilla") { setModsNotice("Для модов выбери Fabric или Forge рядом с кнопкой «Играть»."); return; }
    setModSearchBusy(true);
    try {
      const response = await invoke<any>("search_modrinth_mods", { query: modQuery.trim(), gameVersion: selectedVersion, loader });
      const hits = response.hits || [];
      setModResults(hits as ModResult[]);
      setModsNotice(hits.length ? `Найдено проектов: ${hits.length}. Совместимость фильтруется под Minecraft ${selectedVersion} · ${loader}.` : "Ничего не найдено. Попробуй другой запрос.");
    } catch (e) { setModsNotice(String(e).replace(/^Error: /, "")); setModResults([]); }
    finally { setModSearchBusy(false); }
  };

  const installMod = async (mod: ModResult) => {
    if (!selectedProfile) { setModsNotice("Сначала добавь профиль игрока."); setShowAddProfile(true); return; }
    const id = String(mod.project_id || "");
    if (!id) { setModsNotice("Modrinth не вернул ID этого проекта."); return; }
    setModInstallingId(id); setModsNotice("");
    try {
      const filename = await invoke<string>("install_modrinth_mod", { projectId: id, gameVersion: selectedVersion, loader: settings.selectedLoader, profileId: selectedProfile.id });
      setModsNotice(`Установлен: ${filename}. Перезапусти игру, если она уже открыта.`);
      addLog(`Установлен мод: ${filename}`);
      await loadInstalledMods();
    } catch (e) { setModsNotice(String(e).replace(/^Error: /, "")); }
    finally { setModInstallingId(""); }
  };

  const pickSkin = async (file?: File) => {
    setSkinMessage("");
    if (!file) return;
    if (!file.type.includes("png") || file.size > 1024 * 1024) { setSkinMessage("Нужен PNG-файл размером до 1 МБ."); return; }
    try {
      const image = await createImageBitmap(file);
      if (image.width !== 64 || ![64, 32].includes(image.height)) {
        image.close(); setSkinMessage("Размер скина должен быть 64×64 или 64×32 пикселя."); return;
      }
      if (image.width !== 64) { image.close(); setSkinMessage("Ширина скина должна быть 64 пикселя."); return; }
      image.close();
      const data = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader(); reader.onload = () => resolve(String(reader.result)); reader.onerror = reject; reader.readAsDataURL(file);
      });
      setSkinName(file.name); setSkinData(data); setSkinMessage("Скин сохранён локально для предпросмотра.");
      localStorage.setItem("optilauncher.skin", JSON.stringify({ name: file.name, data }));
    } catch { setSkinMessage("Не удалось прочитать файл. Попробуй другой PNG."); }
  };

  const navItems: { id: Screen; label: string; icon: typeof Gamepad2 }[] = [
    { id: "home", label: "Главная", icon: Gamepad2 },
    { id: "versions", label: "Версии", icon: Layers3 },
    { id: "mods", label: "Моды и сборки", icon: Blocks },
    { id: "skins", label: "Скины", icon: ImageIcon },
    { id: "settings", label: "Настройки", icon: Settings2 },
    { id: "logs", label: "Логи", icon: FileText },
  ];

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand-row">
          <div className="brand-mark"><span>O</span><i /></div>
          <div className="brand-copy"><strong>Opti<span>Launcher</span></strong><small>BY ROVIX STUDIOS</small></div>
        </div>
        <div className="side-caption">ИГРА</div>
        <nav className="navigation">
          {navItems.map(({ id, label, icon: Icon }) => (
            <button key={id} className={`nav-item ${screen === id ? "active" : ""}`} onClick={() => { setScreen(id); setError(""); }}>
              <Icon size={18} strokeWidth={1.8} /><span>{label}</span>{id === "logs" && <span className="nav-dot" />}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="status-card">
            <div className="status-icon"><ShieldCheck size={16} /></div>
            <div><strong>{isDesktop ? "Безопасный вход" : "Режим предпросмотра"}</strong><span>{isDesktop ? "Токены в хранилище ОС" : "Открой desktop-версию"}</span></div>
          </div>
          <div className="side-footer"><span className="online-dot" /> {isDesktop ? "Система готова" : "UI Preview"}<span className="version-number">v0.3.0</span></div>
        </div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <div className="breadcrumb"><span>OptiLauncher</span><span className="crumb-slash">/</span><strong>{navItems.find((n) => n.id === screen)?.label}</strong></div>
          <div className="topbar-right">
            <div className={`connection-state ${isDesktop ? "connected" : "preview"}`}><span />{isDesktop ? "Desktop" : "Preview mode"}</div>
            <button className="icon-button" title="Обновить версии" onClick={() => void loadManifest()} disabled={loadingManifest}><RefreshCw size={16} className={loadingManifest ? "spin" : ""} /></button>
            <button className="profile-chip" onClick={() => { setScreen("home"); setShowAddProfile(true); }}><div className="tiny-avatar">{selectedProfile?.name?.[0]?.toUpperCase() || "?"}</div><span>{selectedProfile?.name || "Нет профиля"}</span><ChevronDown size={14} /></button>
          </div>
        </header>

        <div className="content-scroll">
          {error && <div className="error-banner"><AlertCircle size={17} /><span>{error}</span><button onClick={() => setError("")}><X size={16} /></button></div>}
          {screen === "home" && (
            <section className="page home-page">
              <div className="welcome-line"><div><div className="eyebrow"><span className="eyebrow-star"><Sparkles size={13} /></span> MINECRAFT LAUNCHER</div><h1>Играй. Создавай.<br /><span>Исследуй миры.</span></h1><p className="page-description">Все версии, профили и моды — в одном месте.</p></div><div className="build-pill"><span className="online-dot" /> {isDesktop ? "ПРИЛОЖЕНИЕ ГОТОВО" : "ПРЕДПРОСМОТР"}</div></div>
              <div className="hero-card">
                <div className="hero-glow" /><div className="pixel-sun" /><div className="hero-content"><div className="hero-label"><span className="release-badge">MINECRAFT</span><span className="hero-muted">JAVA EDITION</span></div><h2>Minecraft:<br /><em>Java Edition</em></h2><p>Подготовь свою версию, выбери профиль<br />и отправляйся в новое приключение.</p>
                  <div className="hero-actions launcher-controls">
                    <button className="primary-button play-button" onClick={() => void launch()} disabled={launching || loadingManifest}><Play size={18} fill="currentColor" />{launching ? "Запускаем…" : "Играть"}<span className="button-key">↵</span></button>
                    <label className="launch-select version-select-control" title="Версия Minecraft"><Layers3 size={15} /><select aria-label="Версия Minecraft" value={selectedVersion} onChange={(e) => chooseVersion(e.target.value)}>{versions.filter((v) => v.type === "release").map((v) => <option key={v.id} value={v.id}>{v.id} · Release</option>)}{versions.filter((v) => v.type !== "release").slice(0, 12).map((v) => <option key={v.id} value={v.id}>{v.id} · {v.type}</option>)}</select><ChevronDown size={14} /></label>
                    <label className="launch-select loader-select-control" title="Модлоадер"><Blocks size={15} /><select aria-label="Модлоадер" value={settings.selectedLoader || "vanilla"} onChange={(e) => { const next = { ...settings, selectedLoader: e.target.value, selectedVersion }; setSettings(next); if (isDesktop) void invoke("save_settings", { settings: next }).catch((err) => addLog(`Не удалось сохранить модлоадер: ${String(err)}`)); else localStorage.setItem("optilauncher.settings", JSON.stringify(next)); }}><option value="vanilla">Vanilla</option><option value="fabric">Fabric</option><option value="forge">Forge</option></select><ChevronDown size={14} /></label>
                  </div>
                </div>
                <div className="pixel-landscape" aria-hidden="true"><div className="mountain mountain-back" /><div className="mountain mountain-front" /><div className="pixel-tree tree-a" /><div className="pixel-tree tree-b" /><div className="water-line" /></div>
                <div className="hero-side-label">JAVA EDITION <span>↗</span></div>
              </div>

              <div className="section-heading"><div><span className="eyebrow">БЫСТРЫЙ ДОСТУП</span><h2>Игровой центр</h2></div><button className="text-button" onClick={() => setScreen("settings")}>Настройки <ExternalLink size={14} /></button></div>
              <div className="quick-grid">
                <div className="quick-card version-quick"><div className="quick-card-top"><div className="quick-icon violet"><Layers3 size={18} /></div><span className="tiny-status">{versions.length ? "МАНИФЕСТ ДОСТУПЕН" : "ЗАГРУЗКА"}</span></div><div className="quick-title">Версия игры</div><div className="quick-main-value">{selectedVersion || "Не выбрана"}<ChevronDown size={17} /></div><div className="quick-note">{versions.find((v) => v.id === selectedVersion)?.type === "snapshot" ? "Snapshot / экспериментальная" : `${(settings.selectedLoader || "vanilla").toUpperCase()} · Java Edition`}</div><button className="quick-card-action" onClick={() => setScreen("versions")}>Все версии <span>→</span></button></div>
                <div className="quick-card profile-quick"><div className="quick-card-top"><div className="quick-icon blue"><UserRound size={18} /></div><span className="tiny-status">{selectedProfile?.kind === "microsoft" ? "MICROSOFT АККАУНТ" : "ПРОФИЛЬ ИГРОКА"}</span></div><div className="quick-title">Игрок</div><div className="quick-main-value">{selectedProfile?.name || "Создай профиль"}</div><div className="quick-note">{selectedProfile?.kind === "microsoft" ? "Лицензионный аккаунт · Microsoft" : selectedProfile ? "Offline-профиль · только совместимые серверы" : "Добавь Microsoft или локальный профиль"}</div><button className="quick-card-action" onClick={() => setShowAddProfile(true)}>Сменить профиль <span>→</span></button></div>
                <div className="quick-card memory-quick"><div className="quick-card-top"><div className="quick-icon green"><MemoryStick size={18} /></div><span className="tiny-status">JAVA HEAP</span></div><div className="quick-title">Выделенная память</div><div className="quick-main-value">{settings.ramGb} <small>GB</small></div><div className="ram-track"><span style={{ width: `${settings.ramGb / 16 * 100}%` }} /></div><div className="quick-note">{settings.minRamGb} GB минимум · {settings.ramGb} GB максимум</div><button className="quick-card-action" onClick={() => setScreen("settings")}>Изменить RAM <span>→</span></button></div>
              </div>

              {launching && <div className="progress-panel"><div className="progress-header"><div><LoaderCircle size={17} className="spin" /><strong>{phase || "Подготовка игры"}</strong></div><span>{progress.total ? `${progressPct}%` : "…"}</span></div><div className="progress-track"><span style={{ width: `${progressPct}%` }} /></div><div className="progress-meta"><span>{progress.label || "Подготавливаем файлы"}</span><span>{progress.done}/{progress.total || "—"} файлов</span></div></div>}

              <div className="bottom-panels"><div className="info-panel"><div className="panel-symbol"><Zap size={17} /></div><div><strong>Лёгкий и быстрый</strong><p>Встроенная Java загружается автоматически, если подходящая версия не найдена.</p></div></div><div className="info-panel"><div className="panel-symbol shield"><ShieldCheck size={17} /></div><div><strong>Подключай свой аккаунт</strong><p>Вход Microsoft проверяет доступ к Minecraft Java Edition. Для обычного офлайн-профиля можно использовать локальный ник.</p></div></div></div>
            </section>
          )}

          {screen === "versions" && (
            <section className="page">
              <div className="page-title-row"><div><div className="eyebrow">GAME LIBRARY</div><h1>Версии <span>игры</span></h1><p className="page-description">Выбери официальную версию Minecraft Java Edition.</p></div><button className="secondary-button compact" onClick={() => void loadManifest()} disabled={loadingManifest}><RefreshCw size={16} className={loadingManifest ? "spin" : ""} /> Обновить список</button></div>
              <div className="version-toolbar"><div className="search-box"><Search size={17} /><input value={versionQuery} onChange={(e) => setVersionQuery(e.target.value)} placeholder="Найти версию…" /></div><div className="segmented-filter">{[{ value: "all", label: "Все" }, { value: "release", label: "Релизы" }, { value: "snapshot", label: "Снапшоты" }].map((f) => <button key={f.value} className={versionFilter === f.value ? "selected" : ""} onClick={() => setVersionFilter(f.value)}>{f.label}</button>)}</div></div>
              <div className="version-list-header"><span>ВЕРСИЯ</span><span>ТИП</span><span>ДАТА ВЫПУСКА</span><span>ДЕЙСТВИЕ</span></div>
              <div className="version-list">{filteredVersions.slice(0, 180).map((version) => <button key={version.id} className={`version-row ${selectedVersion === version.id ? "chosen" : ""}`} onClick={() => chooseVersion(version.id)}><div className="version-name"><div className={`version-icon ${version.type === "snapshot" ? "snapshot" : ""}`}><Layers3 size={17} /></div><div><strong>{version.id}</strong><small>{version.type === "release" ? "Minecraft Java Edition" : "Development snapshot"}</small></div></div><div><span className={`version-tag ${version.type}`}>{version.type === "release" ? "Release" : version.type}</span></div><div className="version-date">{prettyDate(version.releaseTime)}</div><div className="version-select-action">{selectedVersion === version.id ? <><Check size={16} /> Выбрана</> : "Выбрать"}</div></button>)}
                {filteredVersions.length === 0 && <div className="empty-state"><Search size={25} /><strong>Ничего не найдено</strong><span>Попробуй изменить запрос или фильтр.</span></div>}
              </div>
              <div className="list-footnote"><Info size={14} /> Показаны первые 180 подходящих версий. Список приходит из официального манифеста Mojang.</div>
              <div className="sticky-launch"><div><span className="tiny-status">ВЫБРАНО ДЛЯ ЗАПУСКА</span><strong>{selectedVersion || "Не выбрана"}</strong></div><button className="primary-button" disabled={!selectedVersion || launching} onClick={() => void launch()}><Play size={16} fill="currentColor" /> Играть на этой версии</button></div>
            </section>
          )}

          {screen === "mods" && (
            <section className="page mods-page">
              <div className="page-title-row"><div><div className="eyebrow">MOD LIBRARY</div><h1>Моды <span>и дополнения</span></h1><p className="page-description">Находи моды на Modrinth под выбранную версию и загрузчик.</p></div><div className="mods-loader-badge"><Blocks size={16} /> {(settings.selectedLoader || "vanilla").toUpperCase()} · {selectedVersion || "Версия не выбрана"}</div></div>
              <div className="modrinth-source-card"><div className="modrinth-source-mark">M</div><div><strong>Каталог Modrinth</strong><p>Официальный API · поиск и загрузка без API-ключа</p></div><a href="https://modrinth.com/mods" target="_blank" rel="noreferrer">Открыть каталог <ExternalLink size={13} /></a></div>
              <div className="mods-search-row"><div className="search-box mods-search-box"><Search size={18} /><input value={modQuery} onChange={(e) => setModQuery(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") void searchMods(); }} placeholder="Например: Sodium, JEI, minimap…" /></div><button className="primary-button" onClick={() => void searchMods()} disabled={modSearchBusy}>{modSearchBusy ? <LoaderCircle size={16} className="spin" /> : <Search size={16} />} Найти моды</button></div>
              {modsNotice && <div className={`mods-notice ${modsNotice.startsWith("Установлен") ? "success" : ""}`}><Info size={15} /><span>{modsNotice}</span></div>}
              {settings.selectedLoader === "vanilla" && <div className="note-card mods-warning"><Info size={16} /><span>Для установки модов сначала выбери Fabric или Forge рядом с кнопкой «Играть» на главной.</span></div>}
              <div className="mod-results-grid">{modResults.map((mod) => {
                const id = String(mod.project_id || "");
                const title = mod.title || mod.slug || "Без названия";
                const author = mod.author || "неизвестного автора";
                return <article className="mod-result-card" key={id}><div className="mod-card-heading">{mod.icon_url ? <img src={mod.icon_url} alt="" /> : <div className="mod-placeholder-icon"><Blocks size={21} /></div>}<div><h3>{title}</h3><small>от {author}</small></div></div><p>{mod.description || "Описание проекта не предоставлено."}</p><div className="mod-card-meta"><span><Download size={13} /> {Intl.NumberFormat("ru-RU", { notation: "compact" }).format(mod.downloads || 0)}</span><span>Modrinth</span></div><div className="mod-card-actions"><button className="primary-button" disabled={settings.selectedLoader === "vanilla" || !!modInstallingId} onClick={() => void installMod(mod)}>{modInstallingId === id ? <LoaderCircle size={15} className="spin" /> : <Download size={15} />} Установить</button><button className="icon-button" title="Открыть страницу проекта" onClick={() => { window.open(`https://modrinth.com/mod/${mod.slug || id}`, "_blank", "noopener,noreferrer"); }}><ExternalLink size={15} /></button></div></article>;
              })}</div>
              {modResults.length === 0 && <div className="mods-empty"><div><Blocks size={25} /></div><h3>Найди мод для своей сборки</h3><p>Результаты отфильтруются по выбранной версии Minecraft и загрузчику.</p></div>}
              <div className="installed-mods-panel"><div className="installed-mods-header"><div><h3>Установленные моды</h3><p>Папка профиля · {selectedProfile?.name || "профиль не выбран"}</p></div><span>{installedMods.length} файлов</span></div>{installedMods.length ? <div className="installed-mods-list">{installedMods.map((m) => <div key={m.fileName}><Blocks size={15} /><span>{m.fileName}</span><Check size={14} /></div>)}</div> : <p className="installed-empty">Пока пусто. Установленные `.jar`-файлы появятся здесь.</p>}</div>
              <div className="note-card"><Info size={15} /><span>OptiLauncher скачивает выбранный файл в папку профиля. Некоторые моды требуют дополнительных зависимостей, например Fabric API; их нужно установить отдельно.</span></div>
            </section>
          )}

          {screen === "skins" && (
            <section className="page">
              <div className="page-title-row"><div><div className="eyebrow">PLAYER CUSTOMIZATION</div><h1>Твои <span>скины</span></h1><p className="page-description">Загрузи PNG и сохрани его в локальном предпросмотре.</p></div><div className="page-icon-tile"><ImageIcon size={22} /></div></div>
              <div className="skin-layout"><div className="skin-preview-card"><div className="skin-card-heading"><div><span className="eyebrow">PREVIEW</span><h3>{skinName || "Steve / Alex"}</h3></div><span className="local-tag"><span /> ЛОКАЛЬНО</span></div><div className="skin-stage"><div className="checkerboard" />{skinData ? <img className="skin-preview-image" src={skinData} alt="Предпросмотр загруженного скина" /> : <div className="pixel-character"><div className="char-head"><i /><b /></div><div className="char-body" /><div className="char-arm arm-left" /><div className="char-arm arm-right" /><div className="char-leg leg-left" /><div className="char-leg leg-right" /></div>}<div className="stage-label">64 × 64 PNG</div></div><div className="skin-preview-footer"><span><Check size={14} /> {skinData ? "Файл сохранён" : "Предпросмотр заглушки"}</span><span>MAX 1 MB</span></div></div>
                <div className="skin-upload-card"><div className="upload-icon"><ImageIcon size={21} /></div><h3>Добавить новый скин</h3><p>Выбери стандартный PNG-файл Minecraft. Поддерживаются размеры 64×64 и 64×32 пикселя.</p><label className="upload-dropzone"><input type="file" accept="image/png,.png" onChange={(e) => void pickSkin(e.target.files?.[0])} /><ArrowDownToLine size={22} /><strong>Нажми, чтобы выбрать файл</strong><span>или перетащи PNG сюда</span></label>{skinMessage && <div className={`skin-message ${skinMessage.startsWith("Скин") ? "success" : ""}`}>{skinMessage.startsWith("Скин") && <Check size={14} />}{skinMessage}</div>}<div className="upload-rules"><div><Check size={14} /> Только PNG</div><div><Check size={14} /> До 1 МБ</div><div><Check size={14} /> 64×64 / 64×32</div></div><div className="note-card"><Info size={16} /><span>В этой сборке скин сохраняется только для предпросмотра интерфейса. Загрузка скина в аккаунт Microsoft и его применение в Minecraft ещё не подключены.</span></div></div></div>
            </section>
          )}

          {screen === "settings" && (
            <section className="page settings-page">
              <div className="page-title-row"><div><div className="eyebrow">PREFERENCES</div><h1>Настройки <span>лаунчера</span></h1><p className="page-description">Подстрой запуск Minecraft под свой компьютер.</p></div><div className="page-icon-tile"><Settings2 size={22} /></div></div>
              <div className="settings-grid"><div className="settings-card"><div className="settings-card-title"><div className="setting-glyph purple"><MemoryStick size={18} /></div><div><h3>Память Java</h3><p>Размер памяти, доступной игре</p></div></div><div className="setting-control"><div className="control-label"><span>Максимальная память</span><strong>{settings.ramGb} GB</strong></div><input className="range-control" type="range" min="2" max="16" step="1" value={settings.ramGb} onChange={(e) => setSettings((s) => ({ ...s, ramGb: Number(e.target.value), minRamGb: Math.min(s.minRamGb, Number(e.target.value) - 1) }))} /><div className="range-markers"><span>2 GB</span><span>8 GB</span><span>16 GB</span></div></div><div className="setting-control"><div className="control-label"><span>Стартовая память</span><strong>{settings.minRamGb} GB</strong></div><input className="range-control" type="range" min="1" max={Math.max(1, settings.ramGb - 1)} step="1" value={settings.minRamGb} onChange={(e) => setSettings((s) => ({ ...s, minRamGb: Number(e.target.value) }))} /><div className="range-markers"><span>1 GB</span><span>Рекомендуется 2 GB</span></div></div><div className="hint-card"><Info size={15} /><span>Обычно Minecraft хватает 4–6 GB. Не выделяй игре всю оперативную память компьютера.</span></div></div>
                <div className="settings-card"><div className="settings-card-title"><div className="setting-glyph blue"><Laptop size={18} /></div><div><h3>Окно игры</h3><p>Стартовое разрешение Minecraft</p></div></div><div className="form-grid"><label className="form-field"><span>Ширина</span><select value={settings.resolutionWidth} onChange={(e) => setSettings((s) => ({ ...s, resolutionWidth: Number(e.target.value) }))}>{[854, 1024, 1280, 1366, 1600, 1920, 2560].map((n) => <option key={n} value={n}>{n}px</option>)}</select></label><label className="form-field"><span>Высота</span><select value={settings.resolutionHeight} onChange={(e) => setSettings((s) => ({ ...s, resolutionHeight: Number(e.target.value) }))}>{[480, 600, 720, 768, 900, 1080, 1440].map((n) => <option key={n} value={n}>{n}px</option>)}</select></label></div><div className="setting-control"><div className="control-label"><span>Java Runtime path</span><span className="optional-label">Необязательно</span></div><input className="text-input" value={settings.javaPath} onChange={(e) => setSettings((s) => ({ ...s, javaPath: e.target.value }))} placeholder={navigator.platform.toLowerCase().includes("win") ? "C:\\Program Files\\Java\\bin\\java.exe" : "/usr/bin/java"} /><small className="field-help">Пустое поле — лаунчер попробует найти или скачать подходящую Java.</small></div></div>
                <div className="settings-card full-settings-card"><div className="settings-card-title"><div className="setting-glyph green"><ShieldCheck size={18} /></div><div><h3>Данные приложения</h3><p>Информация о том, где хранятся файлы</p></div></div><div className="storage-row"><div className="storage-leading"><div className="storage-icon"><HardDrive size={18} /></div><div><strong>Папка OptiLauncher</strong><small>Профили, настройки, библиотеки, ресурсы и Java</small></div></div><span className="storage-location">AppData / OptiLauncher</span></div><div className="storage-row"><div className="storage-leading"><div className="storage-icon"><ShieldCheck size={18} /></div><div><strong>Аутентификация</strong><small>Защищённый вход · токен обновления хранится в системе</small></div></div><span className="muted-value">{profiles.some((p) => p.kind === "microsoft") ? "Microsoft: подключён" : "Microsoft: не подключён"}</span></div><div className="auth-info-strip"><ShieldCheck size={16} /><div><strong>Вход Microsoft</strong><small>Нажми «Войти»: откроется обычная страница Microsoft, после входа лаунчер сам проверит доступ к Minecraft Java Edition.</small></div></div></div></div>
              <div className="settings-actions"><span className="settings-note"><Info size={14} /> Изменения применятся к следующему запуску игры.</span><button className="primary-button" onClick={() => void saveSettings()}>{settingsSaved ? <Check size={17} /> : <Check size={17} />}{settingsSaved ? "Сохранено" : "Сохранить настройки"}</button></div>
            </section>
          )}

          {screen === "logs" && (
            <section className="page">
              <div className="page-title-row"><div><div className="eyebrow">DIAGNOSTICS</div><h1>Журнал <span>событий</span></h1><p className="page-description">События лаунчера и вывод процесса Minecraft.</p></div><button className="secondary-button compact" onClick={() => { setLogs([]); setError(""); }}><Trash2 size={15} /> Очистить</button></div>
              <div className="logs-toolbar"><div><span className="log-led" /> LIVE OUTPUT <span className="logs-count">{logs.length} записей</span></div><button onClick={() => { void navigator.clipboard?.writeText(logs.join("\n")); }}><FileText size={14} /> Копировать текст</button></div><div className="terminal"><div className="terminal-top"><div className="terminal-lights"><i /><i /><i /></div><span>optilauncher — console</span><Activity size={14} /></div><div className="terminal-content">{logs.length === 0 ? <div className="terminal-empty">Журнал очищен. Новые события появятся здесь.</div> : logs.map((line, i) => <div className="log-line" key={`${i}-${line}`}><span className="log-index">{String(i + 1).padStart(3, "0")}</span><span className={line.toLowerCase().includes("ошибка") || line.toLowerCase().includes("error") ? "log-error" : line.includes("успеш") || line.includes("готово") ? "log-success" : ""}>{line}</span></div>)}</div></div><div className="logs-disclaimer"><Info size={15} /><span>Логи могут содержать имена файлов и сообщения игры. Refresh-токен Microsoft хранится в системном хранилище; access-токены не записываются в логи.</span></div>
            </section>
          )}

          <footer className="page-footer"><span>OptiLauncher <b>·</b> Made for your next world</span><span><span className="online-dot" /> {isDesktop ? "All systems operational" : "Desktop connection required"}</span></footer>
        </div>
      </main>

      {showAddProfile && <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) setShowAddProfile(false); }}><div className="modal-card profile-modal"><button className="modal-close" onClick={() => setShowAddProfile(false)}><X size={18} /></button><div className="modal-icon"><Users size={22} /></div><div className="eyebrow">ИГРОВОЙ ПРОФИЛЬ</div><h2>Добавить профиль</h2><p>Подключи аккаунт Microsoft для игры с лицензией или создай локальный профиль.</p><div className="microsoft-login-box"><div className="microsoft-logo"><span>Microsoft</span></div><div className="microsoft-login-copy"><strong>Вход через Microsoft</strong><small>Вход откроется в браузере, профиль проверится автоматически</small></div><button className="secondary-button" onClick={() => void microsoftLogin()} disabled={microsoftLoginBusy}>{microsoftLoginBusy ? <LoaderCircle size={15} className="spin" /> : <ExternalLink size={15} />}{microsoftLoginBusy ? "Ожидаем вход…" : "Войти"}</button></div>{microsoftLoginBusy && <div className="login-progress-note"><LoaderCircle size={16} className="spin" /><span>Заверши вход в браузере. После проверки аккаунт появится здесь автоматически.</span></div>}{profileError && <div className="profile-error"><AlertCircle size={15} /><span>{profileError}</span></div>}<div className="modal-divider-label"><span>ИЛИ ЛОКАЛЬНЫЙ ПРОФИЛЬ</span></div><label className="form-field"><span>Ник игрока</span><input className="text-input" autoFocus value={profileName} maxLength={16} onChange={(e) => setProfileName(e.target.value.replace(/[^A-Za-z0-9_]/g, ""))} onKeyDown={(e) => { if (e.key === "Enter") void createProfile(); }} placeholder="YourNickname" /></label><div className="modal-helper"><ShieldCheck size={15} /> 3–16 латинских букв, цифр или подчёркиваний.</div><button className="primary-button modal-submit" onClick={() => void createProfile()} disabled={profileName.length < 3}><Plus size={17} /> Создать профиль</button>
          {profiles.length > 0 && <div className="existing-profiles"><div className="profile-list-title">СОХРАНЁННЫЕ ПРОФИЛИ</div>{profiles.map((p) => <div className={`profile-option ${selectedProfileId === p.id ? "selected" : ""}`} key={p.id} onClick={() => { setSelectedProfileId(p.id); setShowAddProfile(false); }}><div className="tiny-avatar">{p.name[0].toUpperCase()}</div><div><strong>{p.name}</strong><small>{p.kind === "microsoft" ? "Microsoft · Minecraft Java" : "Локальный профиль"}</small></div>{selectedProfileId === p.id && <Check size={16} />}{profiles.length > 1 && <button className="remove-profile" title="Удалить профиль" onClick={(e) => { e.stopPropagation(); void removeProfile(p); }}><Trash2 size={14} /></button>}</div>)}</div>}
        </div></div>}
    </div>
  );
}

export default App;
