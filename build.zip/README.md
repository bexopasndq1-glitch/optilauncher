# OptiLauncher 0.8.0

A compact Minecraft Java Edition launcher built with Tauri 2, React, TypeScript and Rust. OptiLauncher is an independent third-party project and is not affiliated with Mojang or Microsoft.

## Update 0.8.0

- Minecraft itself now prefers `javaw.exe` on Windows to avoid opening a separate Java console window. `java.exe` remains in use for runtime checks and Forge/Fabric installer processes that need console output. If `javaw.exe` is not present, it falls back to `java.exe`.
- Added a generated minimal OptiLauncher logo to the UI, favicon, and Windows application icon. Full artwork is in `public/branding/optilauncher-logo.png`.

## UI update

- Minimal desktop-launcher layout inspired by instance/library launchers: slim icon sidebar, instance quick-launch rows, a searchable instance library, and a compact profile/instance/mods rail.
- Removed the old welcome headline and the publisher tagline to keep the interface focused.
- English is the default interface language. Open **Settings → Language** to switch between English and Russian; the preference is saved automatically.
- Instance creation remains available with custom name, Minecraft version and Vanilla / Fabric / Forge.
- Microsoft sign-in uses the system browser and validates Minecraft Java profile access.
- Modrinth search and single-mod JAR installation are available for the selected instance.
- Java memory, resolution, logs, and instance management remain available.

## Build on Windows

1. Extract the ZIP into a writable folder.
2. Run `BUILD_WINDOWS.bat`. It checks for Node.js/npm, Rust/Cargo, and Visual Studio C++ Build Tools and offers to install missing prerequisites.
3. The Microsoft Client ID is read from `src-tauri/microsoft-client-id.txt` and compiled into the app. Do not add a client secret to the project.
4. The installer is usually generated in `src-tauri/target/release/bundle/nsis/` or `src-tauri/target/release/bundle/msi/`.

## Microsoft sign-in

The configured Client ID must belong to a public/native app registration that supports personal Microsoft accounts. If Minecraft Services rejects the client ID with `Invalid app registration`, follow the official Minecraft support process to request access for your own app registration: https://help.minecraft.net/hc/en-us/articles/16254801392141.

## Current limitations

- The full Tauri build and sign-in flow have not been run in this environment. Dependency installation and Rust builds need to be tested on Windows.
- Modrinth installation downloads individual JARs into the instance folder. Automatic dependency resolution and full `.mrpack` modpack import/export are not implemented.
- Fabric/Forge availability depends on the selected game version and current installer metadata.

## Data and security

Refresh tokens are stored in the operating system credential store. Access tokens are kept in memory. Microsoft passwords are entered only on Microsoft-hosted pages. OAuth uses PKCE and validates the callback state.
