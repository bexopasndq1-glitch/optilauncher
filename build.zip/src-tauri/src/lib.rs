#![allow(clippy::needless_return)]

use anyhow::{anyhow, bail, Context, Result};
use base64::{engine::general_purpose::URL_SAFE_NO_PAD, Engine as _};
use futures::{stream, StreamExt, TryStreamExt};
use keyring::Entry;
use reqwest::Client;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use sha1::{Digest, Sha1};
use sha2::Sha256;
use std::{
    collections::{HashMap, HashSet},
    path::{Path, PathBuf},
    process::Stdio,
    sync::{atomic::{AtomicUsize, Ordering}, Arc},
    time::Duration,
};
use tauri::{Emitter, Manager};
use tokio::{fs, io::{AsyncBufReadExt, AsyncReadExt, AsyncWriteExt, BufReader}, net::TcpListener, process::Command};

const MANIFEST_URL: &str = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json";
const JAVA_ALL_URL: &str = "https://launchermeta.mojang.com/v1/products/java-runtime/2ec0cc96c44e5a76b9c8b7c39df7210883d12871/all.json";
const USER_AGENT: &str = "OptiLauncher/0.8.0";

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct Settings {
    pub ram_gb: u8,
    pub min_ram_gb: u8,
    pub resolution_width: u16,
    pub resolution_height: u16,
    pub selected_version: String,
    pub java_path: String,
    pub theme: String,
    pub language: String,
    pub selected_loader: String,
    pub microsoft_client_id: String,
}

impl Default for Settings {
    fn default() -> Self {
        Self {
            ram_gb: 4,
            min_ram_gb: 1,
            resolution_width: 1280,
            resolution_height: 720,
            selected_version: String::new(),
            java_path: String::new(),
            theme: "dark".into(),
            language: "en".into(),
            selected_loader: "vanilla".into(),
            microsoft_client_id: option_env!("OPTILAUNCHER_MS_CLIENT_ID").unwrap_or("").to_string(),
        }
    }
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Profile {
    pub id: String,
    pub name: String,
    pub uuid: String,
    pub kind: String,
    #[serde(default)]
    pub client_id: Option<String>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Instance {
    pub id: String,
    pub name: String,
    pub version_id: String,
    pub loader_type: String,
    pub created_at: String,
}

#[derive(Clone, Debug)]
struct DownloadJob {
    url: String,
    path: PathBuf,
    sha1: Option<String>,
    size: Option<u64>,
    label: String,
}

fn http_client() -> Result<Client> {
    Ok(Client::builder()
        .connect_timeout(Duration::from_secs(15))
        .timeout(Duration::from_secs(180))
        .user_agent(USER_AGENT)
        .build()?)
}

fn data_dir(app: &tauri::AppHandle) -> Result<PathBuf> {
    let path = app.path().app_data_dir().context("Не удалось определить папку данных приложения")?;
    std::fs::create_dir_all(&path)?;
    Ok(path)
}

fn read_json<T: for<'de> Deserialize<'de> + Default>(path: &Path) -> Result<T> {
    if !path.exists() {
        return Ok(T::default());
    }
    let bytes = std::fs::read(path).with_context(|| format!("Не удалось прочитать {}", path.display()))?;
    Ok(serde_json::from_slice(&bytes).with_context(|| format!("Некорректный JSON в {}", path.display()))?)
}

fn write_json<T: Serialize>(path: &Path, data: &T) -> Result<()> {
    if let Some(parent) = path.parent() { std::fs::create_dir_all(parent)?; }
    let temp = path.with_extension("json.tmp");
    std::fs::write(&temp, serde_json::to_vec_pretty(data)?)?;
    if path.exists() { std::fs::remove_file(path)?; }
    std::fs::rename(temp, path)?;
    Ok(())
}

fn read_settings_from(app: &tauri::AppHandle) -> Result<Settings> {
    let mut settings: Settings = read_json(&data_dir(app)?.join("settings.json"))?;
    if settings.microsoft_client_id.trim().is_empty() {
        settings.microsoft_client_id = option_env!("OPTILAUNCHER_MS_CLIENT_ID").unwrap_or("").to_string();
    }
    Ok(settings)
}

fn profiles_path(app: &tauri::AppHandle) -> Result<PathBuf> { Ok(data_dir(app)?.join("profiles.json")) }
fn instances_path(app: &tauri::AppHandle) -> Result<PathBuf> { Ok(data_dir(app)?.join("instances.json")) }

fn make_offline_uuid(name: &str) -> String {
    let mut bytes = md5::compute(format!("OfflinePlayer:{name}")).0;
    bytes[6] = (bytes[6] & 0x0f) | 0x30;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    uuid::Uuid::from_bytes(bytes).to_string()
}

#[tauri::command]
fn get_settings(app: tauri::AppHandle) -> Result<Settings, String> {
    read_settings_from(&app).map_err(|e| e.to_string())
}

#[tauri::command]
fn save_settings(app: tauri::AppHandle, settings: Settings) -> Result<Settings, String> {
    if !(2..=16).contains(&settings.ram_gb) { return Err("ОЗУ должно быть в пределах 2–16 ГБ".into()); }
    if settings.min_ram_gb < 1 || settings.min_ram_gb >= settings.ram_gb { return Err("Минимальная память должна быть меньше максимальной".into()); }
    if !(640..=7680).contains(&settings.resolution_width) || !(480..=4320).contains(&settings.resolution_height) {
        return Err("Недопустимое разрешение окна игры".into());
    }
    let path = data_dir(&app).map_err(|e| e.to_string())?.join("settings.json");
    write_json(&path, &settings).map_err(|e| e.to_string())?;
    Ok(settings)
}

#[tauri::command]
fn list_profiles(app: tauri::AppHandle) -> Result<Vec<Profile>, String> {
    let path = profiles_path(&app).map_err(|e| e.to_string())?;
    read_json::<Vec<Profile>>(&path).map_err(|e| e.to_string())
}

#[tauri::command]
fn create_offline_profile(app: tauri::AppHandle, name: String) -> Result<Profile, String> {
    let name = name.trim().to_string();
    if name.len() < 3 || name.len() > 16 || !name.chars().all(|c| c.is_ascii_alphanumeric() || c == '_') {
        return Err("Ник должен содержать 3–16 символов: латинские буквы, цифры или _".into());
    }
    let path = profiles_path(&app).map_err(|e| e.to_string())?;
    let mut profiles: Vec<Profile> = read_json(&path).map_err(|e| e.to_string())?;
    if profiles.iter().any(|p| p.name.eq_ignore_ascii_case(&name)) {
        return Err("Профиль с таким ником уже существует".into());
    }
    let profile = Profile {
        id: uuid::Uuid::new_v4().to_string(),
        uuid: make_offline_uuid(&name),
        name,
        kind: "offline".into(),
        client_id: None,
    };
    profiles.push(profile.clone());
    write_json(&path, &profiles).map_err(|e| e.to_string())?;
    Ok(profile)
}

#[tauri::command]
fn delete_profile(app: tauri::AppHandle, profile_id: String) -> Result<(), String> {
    let path = profiles_path(&app).map_err(|e| e.to_string())?;
    let mut profiles: Vec<Profile> = read_json(&path).map_err(|e| e.to_string())?;
    let removed: Vec<Profile> = profiles.iter().filter(|p| p.id == profile_id).cloned().collect();
    profiles.retain(|p| p.id != profile_id);
    if removed.iter().any(|p| p.kind == "microsoft") {
        if let Ok(entry) = Entry::new("com.rovix.optilauncher", &profile_id) { let _ = entry.delete_credential(); }
    }
    write_json(&path, &profiles).map_err(|e| e.to_string())
}

#[tauri::command]
fn list_instances(app: tauri::AppHandle) -> Result<Vec<Instance>, String> {
    read_json::<Vec<Instance>>(&instances_path(&app).map_err(|e| e.to_string())?).map_err(|e| e.to_string())
}

#[tauri::command]
fn create_instance(app: tauri::AppHandle, name: String, version_id: String, loader_type: String) -> Result<Instance, String> {
    let name = name.trim().to_string();
    if name.is_empty() || name.chars().count() > 32 || name.chars().any(|c| c.is_control()) {
        return Err("Название сборки должно содержать от 1 до 32 символов.".into());
    }
    if version_id.trim().is_empty() || version_id.len() > 40 || !version_id.chars().all(|c| c.is_ascii_alphanumeric() || c == '.' || c == '_' || c == '-') {
        return Err("Выбери корректную версию Minecraft.".into());
    }
    let loader_type = loader_type.to_ascii_lowercase();
    if !["vanilla", "fabric", "forge"].contains(&loader_type.as_str()) {
        return Err("Выбери Vanilla, Fabric или Forge.".into());
    }
    let path = instances_path(&app).map_err(|e| e.to_string())?;
    let mut rows: Vec<Instance> = read_json(&path).map_err(|e| e.to_string())?;
    if rows.iter().any(|item| item.name.eq_ignore_ascii_case(&name)) {
        return Err("Сборка с таким названием уже существует. Выбери другое имя.".into());
    }
    let instance = Instance {
        id: uuid::Uuid::new_v4().to_string(),
        name,
        version_id,
        loader_type,
        created_at: chrono_like_now(),
    };
    rows.push(instance.clone());
    write_json(&path, &rows).map_err(|e| e.to_string())?;
    Ok(instance)
}

fn chrono_like_now() -> String {
    // Stable timestamp without an additional crate; useful for sorting/labels only.
    format!("{}", std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or_default())
}

#[tauri::command]
fn delete_instance(app: tauri::AppHandle, instance_id: String) -> Result<(), String> {
    let path = instances_path(&app).map_err(|e| e.to_string())?;
    let mut rows: Vec<Instance> = read_json(&path).map_err(|e| e.to_string())?;
    let before = rows.len();
    rows.retain(|item| item.id != instance_id);
    if rows.len() == before { return Err("Сборка не найдена.".into()); }
    write_json(&path, &rows).map_err(|e| e.to_string())?;
    // Files on disk are intentionally retained so removing a launcher entry cannot delete worlds or mods.
    Ok(())
}

#[tauri::command]
async fn get_manifest() -> Result<Value, String> {
    let client = http_client().map_err(|e| e.to_string())?;
    let response = client.get(MANIFEST_URL).send().await.map_err(|e| format!("Не удалось загрузить список версий: {e}"))?;
    response.error_for_status().map_err(|e| e.to_string())?.json::<Value>().await.map_err(|e| e.to_string())
}

#[tauri::command]
async fn install_and_launch(app: tauri::AppHandle, instance_id: String, profile_id: String) -> Result<(), String> {
    do_install_and_launch(app, instance_id, profile_id).await.map_err(|e| e.to_string())
}

async fn do_install_and_launch(app: tauri::AppHandle, instance_id: String, profile_id: String) -> Result<()> {
    let instances: Vec<Instance> = read_json(&instances_path(&app)?)?;
    let instance = instances.into_iter().find(|i| i.id == instance_id).ok_or_else(|| anyhow!("Выбери или создай сборку перед запуском."))?;
    if uuid::Uuid::parse_str(&instance.id).is_err() { bail!("Идентификатор сборки повреждён. Создай её заново."); }
    let version_id = instance.version_id.clone();
    let loader_type = instance.loader_type.clone();
    if version_id.is_empty() { bail!("У этой сборки не выбрана версия Minecraft."); }
    let profiles: Vec<Profile> = read_json(&profiles_path(&app)?)?;
    let profile = profiles.into_iter().find(|p| p.id == profile_id).ok_or_else(|| anyhow!("Выберите профиль игрока перед запуском."))?;
    let settings = read_settings_from(&app)?;
    let root = data_dir(&app)?.join("game-data");
    let client = http_client()?;
    let (auth_access_token, auth_user_type, auth_xuid) = if profile.kind == "microsoft" {
        let client_id = profile.client_id.as_deref().filter(|v| !v.trim().is_empty()).ok_or_else(|| anyhow!("У Microsoft-профиля отсутствует Client ID. Удали и добавь аккаунт снова."))?;
        let entry = Entry::new("com.rovix.optilauncher", &profile.id).context("Не удалось открыть системное хранилище учётных данных")?;
        let refresh_token = entry.get_password().context("Не удалось прочитать токен Microsoft из системного хранилища. Добавь профиль заново.")?;
        let (ms_access, next_refresh) = refresh_microsoft_token(&client, client_id, &refresh_token).await?;
        if next_refresh != refresh_token { let _ = entry.set_password(&next_refresh); }
        let mc = minecraft_session(&client, &ms_access).await?;
        if mc.uuid != profile.uuid.replace('-', "") && mc.uuid != profile.uuid.replace('-', "").to_lowercase() {
            let _ = app.emit("launcher:log", "Предупреждение: UUID аккаунта Microsoft изменился; используется UUID из профиля.".to_string());
        }
        (mc.access_token, "msa".to_string(), mc.xuid.unwrap_or_default())
    } else { ("0".to_string(), "legacy".to_string(), String::new()) };
    let _ = app.emit("launcher:log", format!("Подготовка Minecraft {version_id} ({loader_type}) для {}…", profile.name));
    let _ = app.emit("launcher:phase", json!({"phase":"prepare", "message":"Получаем метаданные версии"}));

    let manifest: Value = client.get(MANIFEST_URL).send().await?.error_for_status()?.json().await?;
    let entry = manifest["versions"].as_array().and_then(|versions| versions.iter().find(|v| v["id"].as_str() == Some(version_id.as_str())))
        .ok_or_else(|| anyhow!("Версия {version_id} отсутствует в официальном манифесте Mojang."))?;
    let version_url = entry["url"].as_str().ok_or_else(|| anyhow!("В манифесте нет ссылки на version.json"))?;
    let version_hash = entry["sha1"].as_str().map(str::to_owned);
    let version_size = entry["size"].as_u64();
    let base_version_dir = root.join("versions").join(&version_id);
    fs::create_dir_all(&base_version_dir).await?;
    let meta_path = base_version_dir.join(format!("{version_id}.json"));
    download_one(&client, &DownloadJob { url: version_url.into(), path: meta_path.clone(), sha1: version_hash, size: version_size, label: "Метаданные версии".into() }).await?;
    let meta_bytes = fs::read(&meta_path).await?;
    let base_meta: Value = serde_json::from_slice(&meta_bytes).context("Не удалось прочитать метаданные версии")?;
    let launch_version_id = ensure_loader_profile(&app, &client, &root, &version_id, &loader_type, &settings.java_path, &base_meta).await?;
    let meta: Value = if launch_version_id == version_id {
        base_meta
    } else {
        let loader_meta_path = root.join("versions").join(&launch_version_id).join(format!("{launch_version_id}.json"));
        let loader_bytes = fs::read(&loader_meta_path).await.context("Установщик модлоадера не создал профиль запуска")?;
        let loader_meta: Value = serde_json::from_slice(&loader_bytes).context("Профиль модлоадера повреждён")?;
        merge_version_metadata(base_meta, loader_meta)
    };
    let version_dir = root.join("versions").join(&launch_version_id);
    fs::create_dir_all(&version_dir).await?;

    let libraries_dir = root.join("libraries");
    let assets_dir = root.join("assets");
    let instance_dir = root.join("instances").join(&instance.id);
    let natives_dir = version_dir.join("natives");
    fs::create_dir_all(&libraries_dir).await?;
    fs::create_dir_all(&assets_dir).await?;
    // Migrate legacy profile-scoped game data to the first instance that is launched.
    // If the new instance already has mods, merge missing files and never overwrite existing data.
    let legacy_dir = root.join("instances").join(&profile.id);
    if legacy_dir.exists() && legacy_dir != instance_dir {
        if !instance_dir.exists() {
            fs::rename(&legacy_dir, &instance_dir).await.context("Не удалось перенести старые игровые файлы в новую сборку")?;
            let _ = app.emit("launcher:log", format!("Старые игровые данные перенесены в сборку {}.", instance.name));
        } else {
            let source = legacy_dir.clone();
            let destination = instance_dir.clone();
            tokio::task::spawn_blocking(move || copy_dir_missing(&source, &destination))
                .await.context("Не удалось завершить перенос старых игровых данных")??;
            let _ = app.emit("launcher:log", "Старые миры и настройки объединены с выбранной сборкой; существующие файлы не перезаписаны.".to_string());
        }
    }
    fs::create_dir_all(&instance_dir).await?;
    fs::create_dir_all(&natives_dir).await?;

    let _ = app.emit("launcher:phase", json!({"phase":"download", "message":"Загружаем библиотеки и ресурсы игры"}));
    let mut jobs: Vec<DownloadJob> = Vec::new();
    let mut native_jars: Vec<(PathBuf, Vec<String>)> = Vec::new();
    let features = HashMap::from([("has_custom_resolution", true), ("is_demo_user", false)]);
    let os = mc_os_name();
    let arch_bits = if cfg!(target_pointer_width = "64") { "64" } else { "32" };

    if let Some(libs) = meta["libraries"].as_array() {
        for lib in libs {
            if !rules_allow(lib.get("rules"), &features, &os) { continue; }
            let downloads = &lib["downloads"];
            if let Some(artifact) = downloads.get("artifact").filter(|v| v.is_object()) {
                if let Some(job) = job_from_artifact(artifact, &libraries_dir, "Библиотека") { jobs.push(job); }
            }
            if let (Some(natives), Some(classifiers)) = (lib.get("natives").and_then(Value::as_object), downloads.get("classifiers").and_then(Value::as_object)) {
                if let Some(template) = natives.get(&os).and_then(Value::as_str) {
                    let classifier = template.replace("${arch}", arch_bits);
                    if let Some(artifact) = classifiers.get(&classifier) {
                        if let Some(job) = job_from_artifact(artifact, &libraries_dir, "Нативная библиотека") {
                            native_jars.push((job.path.clone(), lib["extract"]["exclude"].as_array().map(|a| a.iter().filter_map(Value::as_str).map(str::to_owned).collect()).unwrap_or_default()));
                            jobs.push(job);
                        }
                    }
                }
            }
        }
    }

    let client_artifact = meta["downloads"]["client"].as_object().ok_or_else(|| anyhow!("У версии нет загрузки client.jar"))?;
    let client_path = base_version_dir.join(format!("{version_id}.jar"));
    jobs.push(DownloadJob {
        url: client_artifact.get("url").and_then(Value::as_str).ok_or_else(|| anyhow!("Нет URL client.jar"))?.to_string(),
        path: client_path.clone(),
        sha1: client_artifact.get("sha1").and_then(Value::as_str).map(str::to_owned),
        size: client_artifact.get("size").and_then(Value::as_u64),
        label: "Minecraft client".into(),
    });

    let asset_index = &meta["assetIndex"];
    let index_id = asset_index["id"].as_str().unwrap_or("legacy").to_string();
    let index_path = assets_dir.join("indexes").join(format!("{index_id}.json"));
    jobs.push(DownloadJob {
        url: asset_index["url"].as_str().ok_or_else(|| anyhow!("У версии нет assetIndex URL"))?.to_string(),
        path: index_path.clone(),
        sha1: asset_index["sha1"].as_str().map(str::to_owned),
        size: asset_index["size"].as_u64(),
        label: "Индекс ресурсов".into(),
    });

    download_many(&app, &client, jobs).await?;
    let index: Value = serde_json::from_slice(&fs::read(&index_path).await?).context("Индекс ресурсов повреждён")?;
    let mut asset_jobs = Vec::new();
    if let Some(objects) = index["objects"].as_object() {
        for (name, object) in objects {
            let Some(hash) = object["hash"].as_str() else { continue };
            if hash.len() < 2 { continue; }
            asset_jobs.push(DownloadJob {
                url: format!("https://resources.download.minecraft.net/{}/{}", &hash[..2], hash),
                path: assets_dir.join("objects").join(&hash[..2]).join(hash),
                sha1: Some(hash.to_string()),
                size: object["size"].as_u64(),
                label: name.clone(),
            });
        }
    }
    download_many(&app, &client, asset_jobs).await?;

    // Поддержка старых asset-indexes: отдельные игры ищут ресурсы по legacy-путям.
    let legacy_dest = if index["virtual"].as_bool().unwrap_or(false) { Some(assets_dir.join("virtual").join("legacy")) } else { None };
    let resources_dest = if index["map_to_resources"].as_bool().unwrap_or(false) { Some(instance_dir.join("resources")) } else { None };
    if legacy_dest.is_some() || resources_dest.is_some() {
        if let Some(objects) = index["objects"].as_object() {
            for (name, object) in objects {
                if let Some(hash) = object["hash"].as_str() {
                    if hash.len() < 2 { continue; }
                    let src = assets_dir.join("objects").join(&hash[..2]).join(hash);
                    if let Some(dest) = &legacy_dest { copy_named_asset(&src, &dest.join(name)).await?; }
                    if let Some(dest) = &resources_dest { copy_named_asset(&src, &dest.join(name)).await?; }
                }
            }
        }
    }

    let _ = app.emit("launcher:phase", json!({"phase":"java", "message":"Проверяем Java Runtime"}));
    for (jar, excludes) in native_jars {
        extract_natives(&jar, &natives_dir, &excludes).with_context(|| format!("Не удалось распаковать нативы {}", jar.display()))?;
    }
    let major = meta["javaVersion"]["majorVersion"].as_u64().unwrap_or(8) as u32;
    let component = meta["javaVersion"]["component"].as_str().unwrap_or("jre-legacy");
    let java = ensure_java(&app, &client, &root, component, major, &settings.java_path).await?;

    let _ = app.emit("launcher:phase", json!({"phase":"launch", "message":"Запускаем игру"}));
    let mut cp: Vec<String> = Vec::new();
    if let Some(libs) = meta["libraries"].as_array() {
        for lib in libs {
            if !rules_allow(lib.get("rules"), &features, &os) { continue; }
            if let Some(artifact) = lib.get("downloads").and_then(|d| d.get("artifact")) {
                if let Some(path) = artifact["path"].as_str() {
                    let full = libraries_dir.join(path);
                    if full.exists() { cp.push(full.to_string_lossy().to_string()); }
                }
            }
        }
    }
    cp.push(client_path.to_string_lossy().to_string());
    let classpath = cp.join(if cfg!(windows) { ";" } else { ":" });
    let version_type = meta["type"].as_str().unwrap_or("release");
    let game_assets = meta["assets"].as_str().unwrap_or(&index_id);
    let mut vars: HashMap<String, String> = HashMap::new();
    vars.insert("auth_player_name".into(), profile.name.clone());
    vars.insert("version_name".into(), launch_version_id.clone());
    vars.insert("game_directory".into(), instance_dir.to_string_lossy().into_owned());
    vars.insert("assets_root".into(), assets_dir.to_string_lossy().into_owned());
    vars.insert("assets_index_name".into(), index_id.clone());
    vars.insert("game_assets".into(), game_assets.to_string());
    vars.insert("auth_uuid".into(), profile.uuid.replace('-', ""));
    vars.insert("auth_access_token".into(), auth_access_token.clone());
    vars.insert("user_type".into(), auth_user_type);
    vars.insert("version_type".into(), version_type.to_string());
    vars.insert("natives_directory".into(), natives_dir.to_string_lossy().into_owned());
    vars.insert("launcher_name".into(), "OptiLauncher".into());
    vars.insert("launcher_version".into(), "0.8.0".into());
    vars.insert("classpath".into(), classpath);
    vars.insert("classpath_separator".into(), if cfg!(windows) { ";" } else { ":" }.into());
    vars.insert("library_directory".into(), libraries_dir.to_string_lossy().into_owned());
    vars.insert("resolution_width".into(), settings.resolution_width.to_string());
    vars.insert("resolution_height".into(), settings.resolution_height.to_string());
    vars.insert("user_properties".into(), "{}".into());
    vars.insert("clientid".into(), "".into());
    vars.insert("auth_xuid".into(), auth_xuid);
    vars.insert("auth_session".into(), format!("token:{}:{}", auth_access_token, profile.uuid.replace('-', "")));

    let mut jvm_args = expand_arg_array(&meta["arguments"]["jvm"], &features, &os);
    if jvm_args.is_empty() {
        jvm_args.extend(["-Djava.library.path=${natives_directory}".into(), "-cp".into(), "${classpath}".into()]);
    }
    jvm_args.retain(|arg| !arg.starts_with("-Xmx") && !arg.starts_with("-Xms"));
    let mut argv = vec![format!("-Xms{}G", settings.min_ram_gb), format!("-Xmx{}G", settings.ram_gb)];
    argv.extend(jvm_args);
    let main_class = meta["mainClass"].as_str().ok_or_else(|| anyhow!("В version.json отсутствует mainClass"))?;
    argv.push(main_class.to_string());
    let mut game_args = if let Some(a) = meta["arguments"]["game"].as_array() {
        expand_arg_array(&Value::Array(a.clone()), &features, &os)
    } else if let Some(old) = meta["minecraftArguments"].as_str() {
        old.split_whitespace().map(str::to_owned).collect()
    } else {
        Vec::new()
    };
    argv.append(&mut game_args);
    for arg in &mut argv { *arg = replace_variables(arg, &vars); }

    let game_java = java_gui_executable(&java);
    let _ = app.emit("launcher:log", format!("Java runtime: {}", java.display()));
    let _ = app.emit("launcher:log", format!("Minecraft executable: {}", game_java.display()));
    let _ = app.emit("launcher:log", format!("Версия подготовлена. Запуск профиля {}…", profile.name));
    let mut cmd = Command::new(&game_java);
    cmd.args(&argv).current_dir(&instance_dir).stdout(Stdio::piped()).stderr(Stdio::piped());
    let mut child = cmd.spawn().with_context(|| format!("Не удалось запустить Minecraft через {}. Проверьте путь Java в настройках.", game_java.display()))?;
    if let Some(stdout) = child.stdout.take() { pump_logs(app.clone(), stdout, "stdout", auth_access_token.clone()); }
    if let Some(stderr) = child.stderr.take() { pump_logs(app.clone(), stderr, "stderr", auth_access_token.clone()); }
    let status = child.wait().await?;
    if status.success() {
        let _ = app.emit("launcher:log", "Игра завершилась.".to_string());
        Ok(())
    } else {
        let code = status.code().map(|c| c.to_string()).unwrap_or_else(|| "unknown".into());
        let _ = app.emit("launcher:log", format!("Minecraft завершился с кодом {code}. Подробности выше."));
        bail!("Minecraft завершился с кодом {code}. Подробности см. во вкладке «Логи».")
    }
}

fn copy_dir_missing(source: &Path, destination: &Path) -> std::io::Result<()> {
    std::fs::create_dir_all(destination)?;
    for entry in std::fs::read_dir(source)? {
        let entry = entry?;
        let source_path = entry.path();
        let destination_path = destination.join(entry.file_name());
        let kind = entry.file_type()?;
        if kind.is_dir() {
            copy_dir_missing(&source_path, &destination_path)?;
        } else if kind.is_file() && !destination_path.exists() {
            std::fs::copy(&source_path, &destination_path)?;
        }
        // Skip symbolic links to avoid following unexpected paths during migration.
    }
    Ok(())
}

fn pump_logs<R>(app: tauri::AppHandle, reader: R, source: &'static str, secret: String)
where R: tokio::io::AsyncRead + Unpin + Send + 'static {
    tokio::spawn(async move {
        let mut lines = BufReader::new(reader).lines();
        while let Ok(Some(line)) = lines.next_line().await {
            let mut safe = line.replace('\0', "");
            if !secret.is_empty() && secret != "0" { safe = safe.replace(&secret, "***"); }
            let _ = app.emit("launcher:log", format!("[{source}] {safe}"));
        }
    });
}

fn job_from_artifact(artifact: &Value, base: &Path, label: &str) -> Option<DownloadJob> {
    Some(DownloadJob {
        url: artifact.get("url")?.as_str()?.to_string(),
        path: base.join(artifact.get("path")?.as_str()?),
        sha1: artifact.get("sha1").and_then(Value::as_str).map(str::to_owned),
        size: artifact.get("size").and_then(Value::as_u64),
        label: label.to_string(),
    })
}

async fn download_one(client: &Client, job: &DownloadJob) -> Result<()> {
    if let Ok(metadata) = fs::metadata(&job.path).await {
        if job.size.map(|s| s == metadata.len()).unwrap_or(false) { return Ok(()); }
        if job.size.is_none() {
            if let Some(expected) = &job.sha1 {
                if sha1_path(&job.path).await.map(|s| s.eq_ignore_ascii_case(expected)).unwrap_or(false) { return Ok(()); }
            }
        }
    }
    if let Some(parent) = job.path.parent() { fs::create_dir_all(parent).await?; }
    let mut temp_name = job.path.as_os_str().to_os_string();
    temp_name.push(".part");
    let part = PathBuf::from(temp_name);
    let response = client.get(&job.url).send().await.with_context(|| format!("Ошибка сети при загрузке {}", job.label))?;
    let response = response.error_for_status().with_context(|| format!("Ошибка HTTP при загрузке {}", job.label))?;
    let mut stream = response.bytes_stream();
    let mut file = fs::File::create(&part).await?;
    let mut hasher = Sha1::new();
    let mut count: u64 = 0;
    while let Some(chunk) = stream.next().await {
        let bytes = chunk?;
        count += bytes.len() as u64;
        hasher.update(&bytes);
        file.write_all(&bytes).await?;
    }
    file.flush().await?;
    drop(file);
    if let Some(size) = job.size {
        if count != size {
            let _ = fs::remove_file(&part).await;
            bail!("Размер файла не совпал при загрузке {} (ожидалось {size}, получено {count})", job.label);
        }
    }
    if let Some(expected) = &job.sha1 {
        let actual = hex::encode(hasher.finalize());
        if !actual.eq_ignore_ascii_case(expected) {
            let _ = fs::remove_file(&part).await;
            bail!("SHA1 не совпал при загрузке {}", job.label);
        }
    }
    if fs::metadata(&job.path).await.is_ok() { let _ = fs::remove_file(&job.path).await; }
    fs::rename(&part, &job.path).await.with_context(|| format!("Не удалось сохранить {}", job.path.display()))?;
    Ok(())
}

async fn sha1_path(path: &Path) -> Result<String> {
    let mut f = fs::File::open(path).await?;
    let mut buf = vec![0u8; 64 * 1024];
    let mut hash = Sha1::new();
    loop {
        use tokio::io::AsyncReadExt;
        let n = f.read(&mut buf).await?;
        if n == 0 { break; }
        hash.update(&buf[..n]);
    }
    Ok(hex::encode(hash.finalize()))
}

async fn download_many(app: &tauri::AppHandle, client: &Client, jobs: Vec<DownloadJob>) -> Result<()> {
    let mut seen = HashSet::new();
    let mut unique = Vec::new();
    for job in jobs {
        if seen.insert(job.path.clone()) { unique.push(job); }
    }
    let total = unique.len();
    let done = Arc::new(AtomicUsize::new(0));
    let _ = app.emit("launcher:progress", json!({"done":0,"total":total,"label":"Подготовка загрузки"}));
    stream::iter(unique.into_iter().map(|job| {
        let client = client.clone();
        let app = app.clone();
        let done = done.clone();
        async move {
            let label = job.label.clone();
            download_one(&client, &job).await?;
            let n = done.fetch_add(1, Ordering::Relaxed) + 1;
            let _ = app.emit("launcher:progress", json!({"done":n,"total":total,"label":label}));
            Ok::<(), anyhow::Error>(())
        }
    }))
    .buffer_unordered(12)
    .try_collect::<Vec<_>>()
    .await?;
    let _ = app.emit("launcher:progress", json!({"done":total,"total":total,"label":"Готово"}));
    Ok(())
}

fn mc_os_name() -> String {
    if cfg!(windows) { "windows".into() }
    else if cfg!(target_os = "macos") { "osx".into() }
    else { "linux".into() }
}

fn rules_allow(rules: Option<&Value>, features: &HashMap<&str, bool>, os_name: &str) -> bool {
    let Some(rules) = rules.and_then(Value::as_array) else { return true; };
    let mut allowed = false;
    for rule in rules {
        if !rule_matches(rule, features, os_name) { continue; }
        allowed = rule["action"].as_str() == Some("allow");
    }
    allowed
}

fn rule_matches(rule: &Value, features: &HashMap<&str, bool>, os_name: &str) -> bool {
    if let Some(name) = rule["os"]["name"].as_str() {
        if name != os_name { return false; }
    }
    if let Some(arch) = rule["os"]["arch"].as_str() {
        let actual = std::env::consts::ARCH;
        if arch != actual && !(arch == "x86" && actual == "x86") { return false; }
    }
    if let Some(feature_rules) = rule["features"].as_object() {
        for (key, expected) in feature_rules {
            let actual = features.get(key.as_str()).copied().unwrap_or(false);
            if expected.as_bool().unwrap_or(false) != actual { return false; }
        }
    }
    true
}

fn expand_arg_array(value: &Value, features: &HashMap<&str, bool>, os: &str) -> Vec<String> {
    let Some(args) = value.as_array() else { return Vec::new(); };
    let mut result = Vec::new();
    for arg in args {
        if let Some(s) = arg.as_str() { result.push(s.to_string()); continue; }
        if !arg.is_object() { continue; }
        if !rules_allow(arg.get("rules"), features, os) { continue; }
        match &arg["value"] {
            Value::String(s) => result.push(s.clone()),
            Value::Array(values) => result.extend(values.iter().filter_map(Value::as_str).map(str::to_owned)),
            _ => {}
        }
    }
    result
}

fn replace_variables(input: &str, vars: &HashMap<String, String>) -> String {
    let mut output = input.to_string();
    for (key, value) in vars { output = output.replace(&format!("${{{key}}}"), value); }
    output
}

fn extract_natives(jar: &Path, dest: &Path, exclude: &[String]) -> Result<()> {
    use std::io;
    std::fs::create_dir_all(dest)?;
    let f = std::fs::File::open(jar)?;
    let mut archive = zip::ZipArchive::new(f)?;
    for idx in 0..archive.len() {
        let mut item = archive.by_index(idx)?;
        let Some(relative) = item.enclosed_name().map(Path::to_path_buf) else { continue; };
        if item.is_dir() || exclude.iter().any(|x| relative.starts_with(x)) { continue; }
        let target = dest.join(relative);
        if let Some(parent) = target.parent() { std::fs::create_dir_all(parent)?; }
        let mut out = std::fs::File::create(target)?;
        io::copy(&mut item, &mut out)?;
    }
    Ok(())
}

async fn copy_named_asset(src: &Path, dst: &Path) -> Result<()> {
    if let Some(parent) = dst.parent() { fs::create_dir_all(parent).await?; }
    fs::copy(src, dst).await?;
    Ok(())
}

// Use java.exe for tooling that needs stdout/stderr (version checks and mod-loader installers).
// On Windows, a configured javaw.exe is normalized to its sibling java.exe when available.
fn java_cli_executable(java: &Path) -> PathBuf {
    #[cfg(windows)] {
        if java.file_name().and_then(std::ffi::OsStr::to_str)
            .is_some_and(|name| name.eq_ignore_ascii_case("javaw.exe")) {
            if let Some(parent) = java.parent() {
                let candidate = parent.join("java.exe");
                if candidate.exists() { return candidate; }
            }
        }
    }
    java.to_path_buf()
}

// Use javaw.exe for Minecraft itself on Windows so no separate Java console window appears.
// Fall back to java.exe only when the runtime does not contain javaw.exe.
fn java_gui_executable(java: &Path) -> PathBuf {
    #[cfg(windows)] {
        if java.file_name().and_then(std::ffi::OsStr::to_str)
            .is_some_and(|name| name.eq_ignore_ascii_case("java.exe")) {
            if let Some(parent) = java.parent() {
                let candidate = parent.join("javaw.exe");
                if candidate.exists() { return candidate; }
            }
        }
    }
    java.to_path_buf()
}

async fn ensure_java(app: &tauri::AppHandle, client: &Client, root: &Path, component: &str, major: u32, configured: &str) -> Result<PathBuf> {
    if !configured.trim().is_empty() {
        let configured_path = java_cli_executable(Path::new(configured.trim()));
        if configured_path.exists() && java_major(&configured_path).await? == major { return Ok(configured_path); }
        bail!("Указанный путь Java не существует или не подходит: для этой версии нужен Java {major}.");
    }
    if let Ok(system_java) = find_system_java().await {
        if java_major(&system_java).await.unwrap_or_default() == major { return Ok(system_java); }
    }

    let _ = app.emit("launcher:log", format!("Подходящая Java {major} не найдена. Загружаем рантайм Mojang…"));
    let all: Value = client.get(JAVA_ALL_URL).send().await?.error_for_status()?.json().await?;
    let platform = runtime_platform();
    let candidates = all.get(&platform).and_then(Value::as_object).and_then(|o| o.get(component)).and_then(Value::as_array)
        .ok_or_else(|| anyhow!("Официальный Java Runtime {component} недоступен для платформы {platform}. Установите Java {major} и укажите её путь в настройках."))?;
    let entry = candidates.first().ok_or_else(|| anyhow!("Манифест Java Runtime {component} пуст."))?;
    let mf = &entry["manifest"];
    let mf_url = mf["url"].as_str().ok_or_else(|| anyhow!("В манифесте Java отсутствует URL"))?;
    let mf_path = root.join("runtimes").join(component).join(".manifest.json");
    download_one(client, &DownloadJob { url: mf_url.into(), path: mf_path.clone(), sha1: mf["sha1"].as_str().map(str::to_owned), size: mf["size"].as_u64(), label: "Java Runtime manifest".into() }).await?;
    let runtime: Value = serde_json::from_slice(&fs::read(&mf_path).await?)?;
    let dir = root.join("runtimes").join(component);
    let mut jobs = Vec::new();
    let mut executable_files = Vec::new();
    let mut link_files: Vec<(PathBuf, String)> = Vec::new();
    if let Some(files) = runtime["files"].as_object() {
        for (relative, info) in files {
            let path = dir.join(relative);
            if !path.starts_with(&dir) || relative.split('/').any(|p| p == "..") { bail!("Недопустимый путь в манифесте Java Runtime"); }
            match info["type"].as_str().unwrap_or("") {
                "directory" => { fs::create_dir_all(&path).await?; }
                "file" => {
                    let raw = &info["downloads"]["raw"];
                    let Some(url) = raw["url"].as_str() else { continue; };
                    jobs.push(DownloadJob { url: url.to_string(), path: path.clone(), sha1: raw["sha1"].as_str().map(str::to_owned), size: raw["size"].as_u64(), label: format!("Java: {relative}") });
                    if info["executable"].as_bool().unwrap_or(false) { executable_files.push(path); }
                }
                "link" => { if let Some(target) = info["target"].as_str() { link_files.push((path, target.to_string())); } }
                _ => {}
            }
        }
    }
    download_many(app, client, jobs).await?;
    for (link_path, target) in link_files {
        let target_root = dir.join(&target);
        let target_sibling = link_path.parent().unwrap_or(&dir).join(&target);
        let source = if target_root.exists() { target_root } else { target_sibling };
        if source.exists() {
            if fs::symlink_metadata(&link_path).await.is_ok() { let _ = fs::remove_file(&link_path).await; }
            #[cfg(unix)] {
                use std::os::unix::fs::symlink;
                symlink(&source, &link_path).with_context(|| format!("Не удалось создать ссылку Java Runtime: {}", link_path.display()))?;
            }
            #[cfg(windows)] {
                fs::copy(&source, &link_path).await.with_context(|| format!("Не удалось скопировать ссылку Java Runtime: {}", link_path.display()))?;
            }
        }
    }
    #[cfg(unix)]
    for path in executable_files {
        use std::os::unix::fs::PermissionsExt;
        let _ = std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o755));
    }
    let java = if cfg!(windows) { dir.join("bin/java.exe") }
        else if cfg!(target_os = "macos") { dir.join("jre.bundle/Contents/Home/bin/java") }
        else { dir.join("bin/java") };
    if !java.exists() { bail!("Java Runtime скачан, но исполняемый файл не найден. Установите Java {major} вручную."); }
    Ok(java)
}

async fn find_system_java() -> Result<PathBuf> {
    let output = Command::new(if cfg!(windows) { "where" } else { "which" })
        .arg("java").output().await?;
    if !output.status.success() { bail!("Java не найдена в PATH"); }
    let text = String::from_utf8_lossy(&output.stdout);
    let first = text.lines().next().ok_or_else(|| anyhow!("Java не найдена"))?.trim();
    let path = PathBuf::from(first);
    if !path.exists() { bail!("Java не найдена"); }
    Ok(path)
}

async fn java_major(java: &Path) -> Result<u32> {
    let output = Command::new(java).arg("-version").output().await?;
    let text = format!("{}{}", String::from_utf8_lossy(&output.stdout), String::from_utf8_lossy(&output.stderr));
    let marker = text.split('"').nth(1).unwrap_or_else(|| text.split_whitespace().find(|s| s.chars().next().is_some_and(|c| c.is_ascii_digit())).unwrap_or(""));
    let version = marker.strip_prefix("1.").unwrap_or(marker);
    let major_text = version.split(['.', '-', '+']).next().unwrap_or("");
    major_text.parse::<u32>().map_err(|_| anyhow!("Не удалось определить версию Java"))
}

fn runtime_platform() -> String {
    match (std::env::consts::OS, std::env::consts::ARCH) {
        ("windows", "x86_64") => "windows-x64".into(),
        ("windows", "aarch64") => "windows-arm64".into(),
        ("windows", _) => "windows-x86".into(),
        ("macos", "aarch64") => "mac-os-arm64".into(),
        ("macos", _) => "mac-os".into(),
        (_, "x86") => "linux-i386".into(),
        (_, "aarch64") => "linux".into(),
        _ => "linux".into(),
    }
}

fn merge_version_metadata(mut parent: Value, child: Value) -> Value {
    let mut libraries = parent["libraries"].as_array().cloned().unwrap_or_default();
    if let Some(child_libs) = child["libraries"].as_array() {
        for lib in child_libs { libraries.push(lib.clone()); }
    }
    let parent_args = parent["arguments"].clone();
    let child_args = child["arguments"].clone();
    if let Some(obj) = child.as_object() {
        for (key, value) in obj {
            if key == "libraries" || key == "arguments" || key == "inheritsFrom" || key == "id" { continue; }
            // An inherited loader profile usually omits client downloads/assets. Keep those from the vanilla version.
            if key == "downloads" && value.get("client").is_none() { continue; }
            if key == "assetIndex" && value.get("url").is_none() { continue; }
            if key == "assets" && !value.is_string() { continue; }
            if key == "javaVersion" && value.get("majorVersion").is_none() { continue; }
            parent[key] = value.clone();
        }
    }
    parent["libraries"] = Value::Array(libraries);
    if parent_args.is_object() || child_args.is_object() {
        let mut jvm = parent_args["jvm"].as_array().cloned().unwrap_or_default();
        let mut game = parent_args["game"].as_array().cloned().unwrap_or_default();
        jvm.extend(child_args["jvm"].as_array().cloned().unwrap_or_default());
        game.extend(child_args["game"].as_array().cloned().unwrap_or_default());
        parent["arguments"] = json!({"jvm": jvm, "game": game});
    }
    parent
}

async fn ensure_loader_profile(
    app: &tauri::AppHandle,
    client: &Client,
    root: &Path,
    minecraft_version: &str,
    loader: &str,
    configured_java: &str,
    base_meta: &Value,
) -> Result<String> {
    let loader = loader.to_ascii_lowercase();
    if loader == "" || loader == "vanilla" { return Ok(minecraft_version.to_string()); }
    if loader != "fabric" && loader != "forge" {
        bail!("Этот модлоадер пока не поддерживается: {loader}. Выбери Vanilla, Fabric или Forge.");
    }
    let major = base_meta["javaVersion"]["majorVersion"].as_u64().unwrap_or(8) as u32;
    let component = base_meta["javaVersion"]["component"].as_str().unwrap_or("jre-legacy");
    let java = ensure_java(app, client, root, component, major, configured_java).await?;
    let installers_dir = root.join("launcher-installers");
    fs::create_dir_all(&installers_dir).await?;
    let (profile_id, installer_url, args) = if loader == "fabric" {
        let loader_list: Value = client.get(format!("https://meta.fabricmc.net/v2/versions/loader/{minecraft_version}"))
            .send().await?.error_for_status()?.json().await.context("Fabric не вернул список версий loader")?;
        let entries = loader_list.as_array().ok_or_else(|| anyhow!("Некорректный ответ Fabric Meta"))?;
        let loader_entry = entries.iter().find(|e| e["loader"]["stable"].as_bool().unwrap_or(false)).or_else(|| entries.first())
            .ok_or_else(|| anyhow!("Fabric пока не поддерживает Minecraft {minecraft_version}"))?;
        let loader_version = loader_entry["loader"]["version"].as_str().ok_or_else(|| anyhow!("Fabric не вернул версию loader"))?;
        let installers: Value = client.get("https://meta.fabricmc.net/v2/versions/installer").send().await?.error_for_status()?.json().await?;
        let installer_version = installers.as_array().and_then(|a| a.iter().find(|v| v["stable"].as_bool().unwrap_or(false)).or_else(|| a.first()))
            .and_then(|v| v["version"].as_str()).ok_or_else(|| anyhow!("Не найдена стабильная версия Fabric Installer"))?;
        let file = format!("fabric-installer-{installer_version}.jar");
        let url = format!("https://maven.fabricmc.net/net/fabricmc/fabric-installer/{installer_version}/{file}");
        (format!("fabric-loader-{loader_version}-{minecraft_version}"), url,
         vec!["client".to_string(), "-dir".into(), root.to_string_lossy().to_string(), "-mcversion".into(), minecraft_version.to_string(), "-loader".into(), loader_version.to_string(), "-downloadMinecraft".into()])
    } else {
        let promos: Value = client.get("https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json").send().await?.error_for_status()?.json().await?;
        let key_recommended = format!("{minecraft_version}-recommended");
        let key_latest = format!("{minecraft_version}-latest");
        let forge_version = promos["promos"].get(&key_recommended).and_then(Value::as_str)
            .or_else(|| promos["promos"].get(&key_latest).and_then(Value::as_str))
            .ok_or_else(|| anyhow!("Forge не публикует установщик для Minecraft {minecraft_version}. Попробуй другую версию игры или Fabric."))?;
        let full_version = format!("{minecraft_version}-{forge_version}");
        let file = format!("forge-{full_version}-installer.jar");
        let url = format!("https://maven.minecraftforge.net/net/minecraftforge/forge/{full_version}/{file}");
        (format!("{minecraft_version}-forge-{forge_version}"), url,
         vec!["--installClient".to_string(), root.to_string_lossy().to_string()])
    };
    let json_path = root.join("versions").join(&profile_id).join(format!("{profile_id}.json"));
    if json_path.exists() {
        let _ = app.emit("launcher:log", format!("Профиль {loader} уже установлен: {profile_id}."));
        return Ok(profile_id);
    }
    let installer_path = installers_dir.join(format!("{loader}-{}-installer.jar", minecraft_version.replace('.', "_")));
    download_one(client, &DownloadJob { url: installer_url, path: installer_path.clone(), sha1: None, size: None, label: format!("Установщик {loader}") }).await?;
    let _ = app.emit("launcher:phase", json!({"phase":"loader", "message":format!("Устанавливаем {loader} для Minecraft {minecraft_version}")}));
    let output = Command::new(&java).arg("-jar").arg(&installer_path).args(&args).output().await
        .with_context(|| format!("Не удалось запустить установщик {loader}. Проверь Java {major}."))?;
    if !output.status.success() {
        let details = String::from_utf8_lossy(&output.stderr);
        bail!("Установщик {loader} завершился с ошибкой: {}", details.lines().rev().take(5).collect::<Vec<_>>().into_iter().rev().collect::<Vec<_>>().join(" | "));
    }
    let json_path = root.join("versions").join(&profile_id).join(format!("{profile_id}.json"));
    if !json_path.exists() { bail!("Установщик {loader} завершился, но профиль запуска не найден: {}", json_path.display()); }
    let _ = app.emit("launcher:log", format!("Модлоадер {loader} установлен для Minecraft {minecraft_version}."));
    Ok(profile_id)
}

#[derive(Clone, Debug)]
struct MinecraftSession {
    access_token: String,
    uuid: String,
    name: String,
    xuid: Option<String>,
}

async fn minecraft_session(client: &Client, ms_access: &str) -> Result<MinecraftSession> {
    let xbl: Value = client.post("https://user.auth.xboxlive.com/user/authenticate").json(&json!({
        "Properties": {"AuthMethod":"RPS", "SiteName":"user.auth.xboxlive.com", "RpsTicket":format!("d={ms_access}")},
        "RelyingParty":"http://auth.xboxlive.com", "TokenType":"JWT"
    })).send().await?.error_for_status()?.json().await.context("Xbox sign-in failed")?;
    let xbl_token = xbl["Token"].as_str().ok_or_else(|| anyhow!("Xbox не вернул токен"))?;
    let uhs = xbl["DisplayClaims"]["xui"][0]["uhs"].as_str().ok_or_else(|| anyhow!("Xbox не вернул user hash"))?;
    let xsts_response = client.post("https://xsts.auth.xboxlive.com/xsts/authorize").json(&json!({
        "Properties": {"SandboxId":"RETAIL", "UserTokens":[xbl_token]},
        "RelyingParty":"rp://api.minecraftservices.com/", "TokenType":"JWT"
    })).send().await?;
    if !xsts_response.status().is_success() {
        let details: Value = xsts_response.json().await.unwrap_or_default();
        let msg = match details["XErr"].as_u64() {
            Some(2148916233) => "В аккаунте Microsoft нет профиля Xbox. Создай его на официальном сайте Xbox.",
            Some(2148916235) => "Xbox Live недоступен для этого аккаунта или региона.",
            Some(2148916238) => "Для детского аккаунта могут потребоваться семейные разрешения Microsoft.",
            _ => "Xbox отклонил вход. Проверь настройки аккаунта и попробуй снова."
        };
        bail!(msg);
    }
    let xsts: Value = xsts_response.json().await?;
    let xsts_token = xsts["Token"].as_str().ok_or_else(|| anyhow!("Xbox XSTS не вернул токен"))?;
    // Preserve the server response: error_for_status() discards the useful
    // Minecraft Services errorMessage (for example, Invalid app registration).
    let mc_response = client.post("https://api.minecraftservices.com/authentication/login_with_xbox")
        .header(reqwest::header::ACCEPT, "application/json")
        .json(&json!({"identityToken":format!("XBL3.0 x={uhs};{xsts_token}")}))
        .send().await.context("Не удалось связаться с Minecraft Services")?;
    if !mc_response.status().is_success() {
        let status = mc_response.status();
        let body = mc_response.text().await.unwrap_or_default();
        let details: Value = serde_json::from_str(&body).unwrap_or(Value::Null);
        let api_message = details["errorMessage"].as_str()
            .or_else(|| details["error"].as_str())
            .unwrap_or("сервер не передал описание ошибки");
        let reason = details.pointer("/details/reason").and_then(Value::as_str).unwrap_or("");

        if status.as_u16() == 403 && api_message.to_ascii_lowercase().contains("invalid app registration") {
            bail!("Minecraft Services отклонил приложение (403: Invalid app registration). Вход Microsoft и Xbox прошёл, но Minecraft Services не разрешил этому Client ID запрашивать Minecraft-токен. Это ограничение регистрации приложения на стороне Minecraft; смена пароля, перенастройка лицензии или redirect URI его не устранят. Нужно запросить разрешение Client ID через официальную поддержку Minecraft/Mojang: https://help.minecraft.net/hc/en-us/articles/16254801392141");
        }
        if reason == "ACCOUNT_SUSPENDED" {
            bail!("Minecraft Services сообщает, что доступ аккаунта к сервису приостановлен. Код HTTP {status}. Обратись в официальную поддержку Minecraft.");
        }
        bail!("Minecraft Services отклонил вход (HTTP {status}): {api_message}");
    }
    let mc: Value = mc_response.json().await.context("Minecraft Services вернул некорректный ответ")?;
    let access_token = mc["access_token"].as_str().ok_or_else(|| anyhow!("Minecraft Services не вернул токен доступа"))?.to_string();
    let profile_response = client.get("https://api.minecraftservices.com/minecraft/profile").bearer_auth(&access_token).send().await?;
    if profile_response.status().as_u16() == 404 { bail!("На данном аккаунте нет лицензии Minecraft: Java Edition или доступа Game Pass, включающего Java Edition, либо ещё не создан профиль Java. Проверь доступ в официальном Minecraft Launcher."); }
    let prof: Value = profile_response.error_for_status()?.json().await?;
    let uuid = prof["id"].as_str().ok_or_else(|| anyhow!("Minecraft не вернул UUID"))?.to_string();
    let name = prof["name"].as_str().ok_or_else(|| anyhow!("Minecraft не вернул имя игрока"))?.to_string();
    let xuid = xbl["DisplayClaims"]["xui"][0]["xid"].as_str().map(str::to_string);
    Ok(MinecraftSession { access_token, uuid, name, xuid })
}

async fn refresh_microsoft_token(client: &Client, client_id: &str, refresh_token: &str) -> Result<(String, String)> {
    let token: Value = client.post("https://login.microsoftonline.com/consumers/oauth2/v2.0/token").form(&[
        ("grant_type", "refresh_token"), ("client_id", client_id), ("refresh_token", refresh_token),
        ("scope", "XboxLive.signin offline_access")
    ]).send().await?.json().await?;
    let access = token["access_token"].as_str().ok_or_else(|| anyhow!("Сессия Microsoft истекла или Client ID неверен. Удали профиль и войди снова."))?.to_string();
    let refresh = token["refresh_token"].as_str().unwrap_or(refresh_token).to_string();
    Ok((access, refresh))
}

#[tauri::command]
async fn microsoft_login(app: tauri::AppHandle, client_id: String) -> Result<Profile, String> {
    let result = microsoft_login_impl(app.clone(), client_id).await;
    if let Err(e) = &result { let _ = app.emit("microsoft:login-error", e.to_string()); }
    result.map_err(|e| e.to_string())
}

async fn microsoft_login_impl(app: tauri::AppHandle, client_id: String) -> Result<Profile> {
    let client_id = client_id.trim().to_string();
    if client_id.len() < 20 || !client_id.contains('-') {
        bail!("Вход Microsoft не настроен в этой сборке. Автору лаунчера нужно указать ID приложения один раз при сборке.");
    }
    let client = http_client()?;

    // Native OAuth Authorization Code + PKCE: login happens on Microsoft's own page.
    // The callback only listens on the local loopback interface and is short-lived.
    let listener = TcpListener::bind(("127.0.0.1", 0)).await.context("Не удалось открыть локальный порт для входа Microsoft")?;
    let port = listener.local_addr()?.port();
    let redirect_uri = format!("http://localhost:{port}");
    let verifier = format!("{}{}", uuid::Uuid::new_v4().simple(), uuid::Uuid::new_v4().simple());
    let challenge = URL_SAFE_NO_PAD.encode(Sha256::digest(verifier.as_bytes()));
    let state = uuid::Uuid::new_v4().to_string();

    let mut auth_url = url::Url::parse("https://login.microsoftonline.com/consumers/oauth2/v2.0/authorize")?;
    auth_url.query_pairs_mut()
        .append_pair("client_id", &client_id)
        .append_pair("response_type", "code")
        .append_pair("redirect_uri", &redirect_uri)
        .append_pair("response_mode", "query")
        .append_pair("scope", "XboxLive.signin offline_access")
        .append_pair("code_challenge", &challenge)
        .append_pair("code_challenge_method", "S256")
        .append_pair("state", &state)
        .append_pair("prompt", "select_account");

    open_external_url(auth_url.as_str()).context("Не удалось открыть браузер для входа Microsoft")?;
    let _ = app.emit("launcher:log", "Ожидание завершения входа Microsoft в браузере…");
    let code = receive_oauth_code(listener, &state, Duration::from_secs(300)).await?;

    let token_response = client.post("https://login.microsoftonline.com/consumers/oauth2/v2.0/token").form(&[
        ("grant_type", "authorization_code"),
        ("client_id", client_id.as_str()),
        ("code", code.as_str()),
        ("redirect_uri", redirect_uri.as_str()),
        ("code_verifier", verifier.as_str()),
        ("scope", "XboxLive.signin offline_access"),
    ]).send().await?;
    let token: Value = token_response.json().await.context("Не удалось прочитать ответ Microsoft")?;
    if !token_response_status_ok(&token) {
        let description = token["error_description"].as_str().or_else(|| token["error"].as_str()).unwrap_or("неизвестная ошибка");
        bail!("Microsoft не завершил вход: {description}");
    }
    let ms_access = token["access_token"].as_str().ok_or_else(|| anyhow!("Microsoft не вернул токен доступа"))?.to_string();
    let mut refresh_token = token["refresh_token"].as_str().ok_or_else(|| anyhow!("Microsoft не вернул токен обновления. Проверь разрешение offline_access."))?.to_string();
    let mc = minecraft_session(&client, &ms_access).await?;
    let path = profiles_path(&app)?;
    let mut profiles: Vec<Profile> = read_json(&path)?;
    let profile_id = profiles.iter().find(|p| p.kind == "microsoft" && p.uuid.eq_ignore_ascii_case(&mc.uuid)).map(|p| p.id.clone())
        .unwrap_or_else(|| uuid::Uuid::new_v4().to_string());
    let entry = Entry::new("com.rovix.optilauncher", &profile_id).context("Не удалось открыть системное хранилище учётных данных")?;
    entry.set_password(&refresh_token).context("Не удалось сохранить токен обновления в системном хранилище Windows")?;
    refresh_token.clear();
    let profile = Profile { id: profile_id, name: mc.name, uuid: mc.uuid, kind: "microsoft".into(), client_id: Some(client_id) };
    profiles.retain(|p| !(p.kind == "microsoft" && p.uuid.eq_ignore_ascii_case(&profile.uuid)));
    profiles.push(profile.clone());
    write_json(&path, &profiles)?;
    let _ = app.emit("launcher:log", format!("Аккаунт Microsoft {} успешно подключён. Токен хранится в системном хранилище.", profile.name));
    Ok(profile)
}

fn token_response_status_ok(token: &Value) -> bool {
    token["access_token"].as_str().is_some()
}

fn open_external_url(url: &str) -> Result<()> {
    #[cfg(target_os = "windows")]
    { std::process::Command::new("rundll32").args(["url.dll,FileProtocolHandler", url]).spawn().context("Не удалось запустить браузер")?; }
    #[cfg(target_os = "macos")]
    { std::process::Command::new("open").arg(url).spawn().context("Не удалось запустить браузер")?; }
    #[cfg(all(unix, not(target_os = "macos")))]
    { std::process::Command::new("xdg-open").arg(url).spawn().context("Не удалось запустить браузер")?; }
    Ok(())
}

async fn receive_oauth_code(listener: TcpListener, expected_state: &str, timeout: Duration) -> Result<String> {
    let deadline = tokio::time::Instant::now() + timeout;
    loop {
        let remaining = deadline.saturating_duration_since(tokio::time::Instant::now());
        if remaining.is_zero() { bail!("Время ожидания входа Microsoft истекло. Попробуй ещё раз."); }
        let (mut stream, _) = tokio::time::timeout(remaining, listener.accept()).await
            .context("Время ожидания входа Microsoft истекло")??;
        let mut buffer = [0_u8; 8192];
        let read = match tokio::time::timeout(Duration::from_secs(5), stream.read(&mut buffer)).await {
            Ok(Ok(n)) => n,
            _ => continue,
        };
        if read == 0 { continue; }
        let request = String::from_utf8_lossy(&buffer[..read]);
        let request_target = request.lines().next().and_then(|line| line.split_whitespace().nth(1)).unwrap_or("/");
        let parsed = url::Url::parse(&format!("http://localhost{request_target}"))?;
        let query: HashMap<String, String> = parsed.query_pairs().map(|(key, value)| (key.into_owned(), value.into_owned())).collect();
        if !query.contains_key("code") && !query.contains_key("error") {
            let _ = stream.write_all(b"HTTP/1.1 204 No Content\r\nConnection: close\r\n\r\n").await;
            continue;
        }
        let fail = |message: &str| format!("<!doctype html><meta charset=\"utf-8\"><title>OptiLauncher</title><body style=\"font:16px Segoe UI,sans-serif;background:#202020;color:#fff;padding:40px\"><h2>{message}</h2><p>Вернись в OptiLauncher.</p></body>");
        if query.get("state").map(String::as_str) != Some(expected_state) {
            let body = fail("Проверка входа не прошла");
            let response = format!("HTTP/1.1 400 Bad Request\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}", body.len(), body);
            let _ = stream.write_all(response.as_bytes()).await;
            bail!("Проверка безопасности Microsoft не прошла. Попробуй войти снова.");
        }
        if let Some(error) = query.get("error") {
            let body = fail("Вход отменён");
            let response = format!("HTTP/1.1 400 Bad Request\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}", body.len(), body);
            let _ = stream.write_all(response.as_bytes()).await;
            bail!("Вход Microsoft отменён или отклонён ({error}).");
        }
        let code = query.get("code").cloned().ok_or_else(|| anyhow!("Microsoft не вернул код авторизации"))?;
        let body = "<!doctype html><meta charset=\"utf-8\"><title>OptiLauncher</title><body style=\"font:16px Segoe UI,sans-serif;background:#202020;color:#fff;padding:40px\"><h2>Вход завершён</h2><p>Можно закрыть эту вкладку и вернуться в OptiLauncher.</p></body>";
        let response = format!("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}", body.len(), body);
        let _ = stream.write_all(response.as_bytes()).await;
        return Ok(code);
    }
}

#[derive(Clone, Debug, Serialize)]
#[serde(rename_all = "camelCase")]
struct InstalledMod {
    file_name: String,
}

#[tauri::command]
async fn search_modrinth_mods(query: String, game_version: String, loader: String) -> Result<Value, String> {
    let client = http_client().map_err(|e| e.to_string())?;
    let facets = vec![vec!["project_type:mod".to_string()], vec![format!("versions:{game_version}")], vec![format!("categories:{loader}")]];
    let facets_json = serde_json::to_string(&facets).map_err(|e| e.to_string())?;
    client.get("https://api.modrinth.com/v2/search")
        .query(&[("query", query.as_str()), ("facets", facets_json.as_str()), ("limit", "30"), ("index", "downloads")])
        .send().await.map_err(|e| format!("Не удалось связаться с Modrinth: {e}"))?
        .error_for_status().map_err(|e| format!("Modrinth вернул ошибку: {e}"))?
        .json::<Value>().await.map_err(|e| e.to_string())
}

#[tauri::command]
async fn install_modrinth_mod(app: tauri::AppHandle, project_id: String, game_version: String, loader: String, instance_id: String) -> Result<String, String> {
    install_modrinth_mod_impl(app, project_id, game_version, loader, instance_id).await.map_err(|e| e.to_string())
}

async fn install_modrinth_mod_impl(app: tauri::AppHandle, project_id: String, game_version: String, loader: String, instance_id: String) -> Result<String> {
    let instances: Vec<Instance> = read_json(&instances_path(&app)?)?;
    let instance = instances.iter().find(|i| i.id == instance_id).ok_or_else(|| anyhow!("Сначала выбери сборку."))?;
    if uuid::Uuid::parse_str(&instance.id).is_err() { bail!("Идентификатор сборки повреждён."); }
    let safe_instance_id = instance.id.clone();
    let client = http_client()?;
    let versions: Value = client.get(format!("https://api.modrinth.com/v2/project/{project_id}/version"))
        .query(&[("game_versions", format!("[\"{game_version}\"]")), ("loaders", format!("[\"{loader}\"]"))])
        .send().await?.error_for_status()?.json().await.context("Не удалось получить совместимые версии мода")?;
    let file = versions.as_array().and_then(|a| a.iter().find_map(|v| {
        v["files"].as_array().and_then(|files| files.iter().find(|f| f["primary"].as_bool().unwrap_or(false)).or_else(|| files.first())).cloned()
    })).ok_or_else(|| anyhow!("Для Minecraft {game_version} и {loader} совместимый файл не найден."))?;
    let url = file["url"].as_str().ok_or_else(|| anyhow!("Modrinth не вернул ссылку на файл"))?;
    let raw_name = file["filename"].as_str().unwrap_or("mod.jar");
    let filename = Path::new(raw_name).file_name().and_then(|n| n.to_str()).filter(|n| n.ends_with(".jar")).unwrap_or("mod.jar").to_string();
    let dest = data_dir(&app)?.join("game-data").join("instances").join(safe_instance_id).join("mods").join(&filename);
    fs::create_dir_all(dest.parent().unwrap()).await?;
    let _ = app.emit("launcher:phase", json!({"phase":"mods", "message":format!("Скачиваем {filename} из Modrinth")}));
    let bytes = client.get(url).send().await?.error_for_status()?.bytes().await?;
    fs::write(&dest, bytes).await?;
    let _ = app.emit("launcher:log", format!("Установлен мод {filename} из Modrinth."));
    Ok(filename)
}

#[tauri::command]
async fn list_installed_mods(app: tauri::AppHandle, instance_id: String) -> Result<Vec<InstalledMod>, String> {
    // Only allow IDs that belong to a saved launcher instance; never accept arbitrary path segments.
    let instances: Vec<Instance> = read_json(&instances_path(&app).map_err(|e| e.to_string())?).map_err(|e| e.to_string())?;
    let instance = instances.iter().find(|instance| instance.id == instance_id)
        .ok_or_else(|| "Сборка не найдена. Сначала создай или выбери сборку.".to_string())?;
    if uuid::Uuid::parse_str(&instance.id).is_err() { return Err("Идентификатор сборки повреждён.".into()); }
    let safe_instance_id = instance.id.clone();
    let dir = data_dir(&app).map_err(|e| e.to_string())?.join("game-data").join("instances").join(safe_instance_id).join("mods");
    let mut results = Vec::new();
    if !dir.exists() { return Ok(results); }
    let mut entries = fs::read_dir(dir).await.map_err(|e| e.to_string())?;
    while let Some(entry) = entries.next_entry().await.map_err(|e| e.to_string())? {
        let path = entry.path();
        if path.extension().and_then(|e| e.to_str()) == Some("jar") {
            if let Some(file_name) = path.file_name().and_then(|n| n.to_str()) { results.push(InstalledMod { file_name: file_name.to_string() }); }
        }
    }
    results.sort_by(|a,b| a.file_name.to_lowercase().cmp(&b.file_name.to_lowercase()));
    Ok(results)
}

pub fn run() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![
            get_settings,
            save_settings,
            list_profiles,
            create_offline_profile,
            delete_profile,
            list_instances,
            create_instance,
            delete_instance,
            get_manifest,
            install_and_launch,
            microsoft_login,
            search_modrinth_mods,
            install_modrinth_mod,
            list_installed_mods
        ])
        .run(tauri::generate_context!())
        .expect("error while running OptiLauncher");
}
