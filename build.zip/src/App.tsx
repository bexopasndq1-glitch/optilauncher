import { useCallback, useEffect, useState } from "react";
import { invoke } from "@tauri-apps/api/core";
import { listen, type UnlistenFn } from "@tauri-apps/api/event";
import {
  Activity, AlertCircle, Blocks, Check, ChevronDown,
  Download, ExternalLink, FileText, Gamepad2, HardDrive,
  Info, Laptop, Layers3, LoaderCircle, MemoryStick, Play,
  Plus, RefreshCw, Search, Settings2, ShieldCheck, Sparkles, Trash2,
  UserRound, Users, X, Zap,
} from "lucide-react";

type Profile = { id: string; name: string; uuid: string; kind: string; clientId?: string | null };
type Settings = {
  ramGb: number;
  minRamGb: number;
  resolutionWidth: number;
  resolutionHeight: number;
  selectedVersion: string;
  javaPath: string;
  theme: string;
  selectedLoader: string;
  microsoftClientId: string;
  language: "en" | "ru";
};
type Version = { id: string; type: string; releaseTime?: string; url?: string; sha1?: string };
type Instance = { id: string; name: string; versionId: string; loaderType: string; createdAt: string };
type Progress = { done: number; total: number; label?: string };
type ModResult = { project_id?: string; slug?: string; title?: string; description?: string; author?: string; downloads?: number; icon_url?: string };
type Screen = "home" | "versions" | "mods" | "settings" | "logs";

const DEFAULT_SETTINGS: Settings = {
  ramGb: 4, minRamGb: 1, resolutionWidth: 1280, resolutionHeight: 720,
  selectedVersion: "", javaPath: "", theme: "dark", selectedLoader: "vanilla", microsoftClientId: "", language: "en",
};
const DEMO_VERSIONS: Version[] = [
  { id: "1.21.11", type: "release", releaseTime: "2025-12-09T00:00:00+00:00" },
  { id: "1.21.10", type: "release", releaseTime: "2025-10-07T00:00:00+00:00" },
  { id: "1.20.6", type: "release", releaseTime: "2024-04-29T00:00:00+00:00" },
  { id: "1.8.9", type: "release", releaseTime: "2015-12-09T00:00:00+00:00" },
  { id: "24w14potato", type: "snapshot", releaseTime: "2024-04-01T00:00:00+00:00" },
];

function desktopAvailable() {
  return typeof window !== "undefined" && "__TAURI_INTERNALS__" in window;
}


function App() {
  const [screen, setScreen] = useState<Screen>("home");
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [versions, setVersions] = useState<Version[]>(DEMO_VERSIONS);
  const [instances, setInstances] = useState<Instance[]>([]);
  const [selectedInstanceId, setSelectedInstanceId] = useState("");
  const [selectedProfileId, setSelectedProfileId] = useState("");
  const [selectedVersion, setSelectedVersion] = useState("");
  const [instanceName, setInstanceName] = useState("My Minecraft");
  const [instanceVersion, setInstanceVersion] = useState("");
  const [instanceLoader, setInstanceLoader] = useState("vanilla");
  const [creatingInstance, setCreatingInstance] = useState(false);
  const [instanceError, setInstanceError] = useState("");
  const [homeSearch, setHomeSearch] = useState("");
  const [profileName, setProfileName] = useState("");
  const [showAddProfile, setShowAddProfile] = useState(false);
  const [showAddInstance, setShowAddInstance] = useState(false);
  const [profileError, setProfileError] = useState("");
  const [microsoftLoginBusy, setMicrosoftLoginBusy] = useState(false);
  const [modQuery, setModQuery] = useState("");
  const [modResults, setModResults] = useState<ModResult[]>([]);
  const [modSearchBusy, setModSearchBusy] = useState(false);
  const [modInstallingId, setModInstallingId] = useState("");
  const [installedMods, setInstalledMods] = useState<{ fileName: string }[]>([]);
  const [modsNotice, setModsNotice] = useState("");
  const [settingsSaved, setSettingsSaved] = useState(false);
  const [loadingManifest, setLoadingManifest] = useState(false);
  const [launching, setLaunching] = useState(false);
  const [progress, setProgress] = useState<Progress>({ done: 0, total: 0, label: "" });
  const [phase, setPhase] = useState("");
  const [logs, setLogs] = useState<string[]>(["OptiLauncher started.", "Waiting for user actions…"]);
  const [error, setError] = useState("");
  const isDesktop = desktopAvailable();
  const language = settings.language === "ru" ? "ru" : "en";
  const t = (english: string, russian: string) => language === "ru" ? russian : english;
  const translateRuntimeText = (value: string) => {
    const messages: Record<string, [string, string]> = {
      "Получаем метаданные версии": ["Fetching version metadata", "Получаем метаданные версии"],
      "Загружаем библиотеки и ресурсы игры": ["Downloading libraries and game assets", "Загружаем библиотеки и ресурсы игры"],
      "Проверяем Java Runtime": ["Checking Java Runtime", "Проверяем Java Runtime"],
      "Запускаем игру": ["Launching game", "Запускаем игру"],
      "Подготовка загрузки": ["Preparing download", "Подготовка загрузки"],
      "Готово": ["Done", "Готово"],
      "Подготовка": ["Preparing", "Подготовка"],
    };
    const found = messages[value];
    return found ? t(found[0], found[1]) : value;
  };

  const addLog = useCallback((line: string) => {
    const time = new Date().toLocaleTimeString(language === "ru" ? "ru-RU" : "en-US", { hour12: false });
    setLogs((old) => [...old.slice(-399), `[${time}] ${line}`]);
  }, [language]);

  const loadManifest = useCallback(async (quiet = false) => {
    if (!quiet) setLoadingManifest(true);
    try {
      const data = await invoke<any>("get_manifest");
      const rows = (data.versions ?? []) as Version[];
      setVersions(rows);
      const latest = data.latest?.release || rows.find((v) => v.type === "release")?.id || "";
      setInstanceVersion((old) => old || settings.selectedVersion || latest);
      addLog(`Mojang manifest updated: ${rows.length} versions.`);
    } catch (e) {
      setInstanceVersion((old) => old || "1.21.11");
      if (isDesktop) {
        setError(t(`Could not load the version list: ${String(e)}`, `Не удалось получить список версий: ${String(e)}`));
        addLog(`Manifest error: ${String(e)}`);
      }
    } finally {
      setLoadingManifest(false);
    }
  }, [addLog, isDesktop, settings.selectedVersion]);

  useEffect(() => {
    const init = async () => {
      if (isDesktop) {
        try {
          const saved = await invoke<Settings>("get_settings");
          setSettings({ ...DEFAULT_SETTINGS, ...saved });
          setSelectedVersion(saved.selectedVersion || "");
        } catch (e) { addLog(`Using default settings: ${String(e)}`); }
        try {
          const rows = await invoke<Profile[]>("list_profiles");
          setProfiles(rows);
          const selected = localStorage.getItem("optilauncher.profile") || "";
          setSelectedProfileId(rows.some((p) => p.id === selected) ? selected : (rows[0]?.id || ""));
        } catch (e) { addLog(`Could not load profiles: ${String(e)}`); }
        try {
          const rows = await invoke<Instance[]>("list_instances");
          setInstances(rows);
          const wanted = localStorage.getItem("optilauncher.selectedInstance") || "";
          const active = rows.find((item) => item.id === wanted) || rows[0];
          setSelectedInstanceId(active?.id || "");
          if (active) {
            setSelectedVersion(active.versionId);
            setSettings((old) => ({ ...old, selectedVersion: active.versionId, selectedLoader: active.loaderType }));
            setInstanceVersion(active.versionId);
            setInstanceLoader(active.loaderType);
          }
        } catch (e) { addLog(`Could not load instances: ${String(e)}`); }
      } else {
        try {
          const saved = localStorage.getItem("optilauncher.settings");
          if (saved) { const parsed = JSON.parse(saved); setSettings({ ...DEFAULT_SETTINGS, ...parsed }); }
          const stored = localStorage.getItem("optilauncher.profiles");
          if (stored) {
            const rows = JSON.parse(stored) as Profile[];
            setProfiles(rows);
            setSelectedProfileId(rows[0]?.id || "");
          }
          const storedInstances = localStorage.getItem("optilauncher.instances");
          if (storedInstances) {
            const rows = JSON.parse(storedInstances) as Instance[];
            setInstances(rows);
            const wanted = localStorage.getItem("optilauncher.selectedInstance") || "";
            const active = rows.find((item) => item.id === wanted) || rows[0];
            setSelectedInstanceId(active?.id || "");
            if (active) {
              setSelectedVersion(active.versionId);
              setInstanceVersion(active.versionId);
              setInstanceLoader(active.loaderType);
              setSettings((old) => ({ ...old, selectedVersion: active.versionId, selectedLoader: active.loaderType }));
            }
          }
        } catch { /* ignore invalid preview cache */ }
      }
      await loadManifest(true);
    };
    void init();
  }, []);

  useEffect(() => {
    if (!isDesktop) return;
    let unlisteners: UnlistenFn[] = [];
    let alive = true;
    void (async () => {
      const handles = await Promise.all([
        listen<string>("launcher:log", (event) => addLog(event.payload)),
        listen<any>("launcher:phase", (event) => setPhase(translateRuntimeText(event.payload.message || event.payload.phase || ""))),
        listen<Progress>("launcher:progress", (event) => setProgress({ ...event.payload, label: translateRuntimeText(event.payload.label || "") })),
      ]);
      if (alive) unlisteners = handles;
      else handles.forEach((f) => f());
    })();
    return () => { alive = false; unlisteners.forEach((f) => f()); };
  }, [isDesktop, addLog]);

  useEffect(() => {
    if (!isDesktop) localStorage.setItem("optilauncher.profiles", JSON.stringify(profiles));
  }, [profiles, isDesktop]);
  useEffect(() => {
    if (selectedProfileId) localStorage.setItem("optilauncher.profile", selectedProfileId);
  }, [selectedProfileId]);


  const selectedProfile = profiles.find((p) => p.id === selectedProfileId);
  const selectedInstance = instances.find((item) => item.id === selectedInstanceId);

  const selectInstance = (instance: Instance) => {
    setSelectedInstanceId(instance.id);
    localStorage.setItem("optilauncher.selectedInstance", instance.id);
    setSelectedVersion(instance.versionId);
    setInstanceVersion(instance.versionId);
    setInstanceLoader(instance.loaderType);
    const next = { ...settings, selectedVersion: instance.versionId, selectedLoader: instance.loaderType };
    setSettings(next);
    if (isDesktop) {
      void invoke("save_settings", { settings: next }).catch((e) => addLog(`Could not save selected instance: ${String(e)}`));
    } else {
      localStorage.setItem("optilauncher.settings", JSON.stringify(next));
    }
    addLog(`Selected instance ${instance.name} · ${instance.versionId} · ${instance.loaderType}.`);
  };

  const createInstance = async () => {
    setInstanceError(""); setError("");
    const name = instanceName.trim();
    if (!name) { setInstanceError(t("Enter an instance name.", "Введи название сборки.")); return; }
    if (!instanceVersion) { setInstanceError(t("Choose a Minecraft version.", "Выбери версию Minecraft.")); return; }
    setCreatingInstance(true);
    try {
      let instance: Instance;
      if (isDesktop) {
        instance = await invoke<Instance>("create_instance", { name, versionId: instanceVersion, loaderType: instanceLoader });
      } else {
        if (instances.some((item) => item.name.toLowerCase() === name.toLowerCase())) throw new Error(t("An instance with this name already exists.", "Сборка с таким названием уже существует."));
        instance = { id: crypto.randomUUID(), name, versionId: instanceVersion, loaderType: instanceLoader, createdAt: String(Date.now()) };
      }
      const nextInstances = [...instances, instance];
      setInstances(nextInstances);
      if (!isDesktop) localStorage.setItem("optilauncher.instances", JSON.stringify(nextInstances));
      selectInstance(instance);
      setInstanceName(""); setShowAddInstance(false);
      addLog(`Created instance ${instance.name} · Minecraft ${instance.versionId} · ${instance.loaderType}.`);
    } catch (e) {
      const message = String(e).replace(/^Error: /, "");
      setInstanceError(message);
    } finally { setCreatingInstance(false); }
  };

  const removeInstance = async (instance: Instance) => {
    if (!window.confirm(t(`Remove “${instance.name}” from the launcher list? Game files and worlds will remain on disk.`, `Убрать «${instance.name}» из списка лаунчера? Файлы игры и миры на диске останутся.`))) return;
    try {
      if (isDesktop) await invoke("delete_instance", { instanceId: instance.id });
      const next = instances.filter((item) => item.id !== instance.id);
      setInstances(next);
      if (!isDesktop) localStorage.setItem("optilauncher.instances", JSON.stringify(next));
      if (selectedInstanceId === instance.id) {
        const nextActive = next[0];
        setSelectedInstanceId(nextActive?.id || "");
        localStorage.setItem("optilauncher.selectedInstance", nextActive?.id || "");
        if (nextActive) selectInstance(nextActive);
        else setSelectedVersion("");
      }
      addLog(`Removed instance “${instance.name}” from the list. Files on disk were preserved.`);
    } catch (e) { setError(String(e).replace(/^Error: /, "")); }
  };
  const progressPct = progress.total > 0 ? Math.min(100, Math.round((progress.done / progress.total) * 100)) : 0;

  const createProfile = async () => {
    setError(""); setProfileError("");
    try {
      const name = profileName.trim();
      if (!isDesktop) {
        if (!/^[A-Za-z0-9_]{3,16}$/.test(name)) throw new Error(t("Player name must contain 3–16 letters, numbers or underscores.", "Ник должен содержать 3–16 латинских букв, цифр или _."));
        if (profiles.some((p) => p.name.toLowerCase() === name.toLowerCase())) throw new Error(t("A profile with this name already exists.", "Такой профиль уже есть."));
        const profile: Profile = { id: crypto.randomUUID(), name, uuid: crypto.randomUUID(), kind: "offline" };
        setProfiles((old) => [...old, profile]); setSelectedProfileId(profile.id);
      } else {
        const profile = await invoke<Profile>("create_offline_profile", { name });
        setProfiles((old) => [...old, profile]); setSelectedProfileId(profile.id);
        addLog(`Created local profile ${profile.name}.`);
      }
      setProfileName(""); setShowAddProfile(false);
    } catch (e) { setError(String(e).replace(/^Error: /, "")); }
  };

  const removeProfile = async (profile: Profile) => {
    if (profiles.length <= 1) { setError(t("Keep at least one profile.", "Нужно оставить хотя бы один профиль.")); return; }
    try {
      if (isDesktop) await invoke("delete_profile", { profileId: profile.id });
      setProfiles((old) => old.filter((p) => p.id !== profile.id));
      if (selectedProfileId === profile.id) setSelectedProfileId(profiles.find((p) => p.id !== profile.id)?.id || "");
      addLog(`Removed profile ${profile.name}.`);
    } catch (e) { setError(String(e)); }
  };

  const updateLanguage = (nextLanguage: "en" | "ru") => {
    const next = { ...settings, language: nextLanguage };
    setSettings(next);
    if (isDesktop) {
      void invoke("save_settings", { settings: next }).catch((e) => addLog(`Could not save language preference: ${String(e)}`));
    } else {
      localStorage.setItem("optilauncher.settings", JSON.stringify(next));
    }
  };

  const saveSettings = async () => {
    setError("");
    try {
      if (settings.minRamGb >= settings.ramGb) throw new Error(t("Minimum memory must be lower than maximum memory.", "Минимальная память должна быть меньше максимальной."));
      const value = { ...settings, selectedVersion };
      if (isDesktop) await invoke("save_settings", { settings: value });
      else localStorage.setItem("optilauncher.settings", JSON.stringify(value));
      setSettings(value); setSettingsSaved(true); addLog("Settings saved.");
      window.setTimeout(() => setSettingsSaved(false), 2200);
    } catch (e) { setError(String(e).replace(/^Error: /, "")); }
  };

  const launch = async (instanceOverride?: Instance) => {
    setError("");
    const activeInstance = instanceOverride || selectedInstance;
    if (!activeInstance) { setError(t("Create an instance first.", "Сначала создай сборку.")); setShowAddInstance(true); return; }
    if (!selectedProfile) { setError(t("Add or select a player profile first.", "Сначала создай или выбери профиль игрока.")); setShowAddProfile(true); return; }
    if (!activeInstance.versionId) { setError(t("This instance has no Minecraft version.", "У сборки не указана версия Minecraft.")); return; }
    if (!isDesktop) { setError(t("Open the installed OptiLauncher desktop app to install and launch Minecraft. This is only a UI preview.", "Для запуска Minecraft открой установленное приложение OptiLauncher. Сейчас работает только предпросмотр.")); return; }
    setLaunching(true); setProgress({ done: 0, total: 0, label: t("Preparing", "Подготовка") });
    addLog(`Launching ${activeInstance.name} · Minecraft ${activeInstance.versionId} · profile ${selectedProfile.name}.`);
    try {
      await invoke("install_and_launch", { instanceId: activeInstance.id, profileId: selectedProfile.id });
    } catch (e) { setError(String(e).replace(/^Error: /, "")); }
    finally { setLaunching(false); setPhase(""); }
  };

  const microsoftLogin = async () => {
    setError(""); setProfileError("");
    const clientId = settings.microsoftClientId.trim();
    if (!isDesktop) { setProfileError(t("Open the installed OptiLauncher desktop app to sign in with Microsoft.", "Для входа через Microsoft открой установленное приложение OptiLauncher.")); return; }
    if (!clientId) { setProfileError(t("Microsoft sign-in is not configured in this build.", "В этой сборке не настроен вход через Microsoft. Установи версию лаунчера, собранную с поддержкой входа.")); return; }
    setMicrosoftLoginBusy(true);
    try {
      const nextSettings = { ...settings, microsoftClientId: clientId };
      await invoke("save_settings", { settings: nextSettings });
      setSettings(nextSettings);
      addLog("Opening the secure Microsoft sign-in page in your browser…");
      const profile = await invoke<Profile>("microsoft_login", { clientId });
      setProfiles((old) => [...old.filter((p) => p.uuid.toLowerCase() !== profile.uuid.toLowerCase()), profile]);
      setSelectedProfileId(profile.id);
      addLog(`Microsoft account connected: ${profile.name}.`);
      setShowAddProfile(false);
    } catch (e) {
      const message = String(e).replace(/^Error: /, "");
      setProfileError(message);
      addLog(`Microsoft sign-in failed: ${message}`);
    } finally {
      setMicrosoftLoginBusy(false);
    }
  };

  const loadInstalledMods = useCallback(async () => {
    if (!isDesktop || !selectedInstanceId) { setInstalledMods([]); return; }
    try { setInstalledMods(await invoke<{ fileName: string }[]>("list_installed_mods", { instanceId: selectedInstanceId })); }
    catch { setInstalledMods([]); }
  }, [isDesktop, selectedInstanceId]);

  useEffect(() => { void loadInstalledMods(); }, [loadInstalledMods]);

  const searchMods = async () => {
    setModsNotice(""); setError("");
    if (!isDesktop) { setModsNotice(t("Open the OptiLauncher desktop app to search and install mods.", "Открой desktop-приложение, чтобы искать и устанавливать моды.")); return; }
    if (!selectedInstance) { setModsNotice(t("Create or select an instance first.", "Сначала создай или выбери сборку.")); setShowAddInstance(true); return; }
    const gameVersion = selectedInstance.versionId;
    const loader = selectedInstance.loaderType;
    if (loader === "vanilla") { setModsNotice(t("Create a Fabric or Forge instance before searching for mods.", "Для модов создай отдельную сборку на Fabric или Forge через «Добавить сборку».")); return; }
    setModSearchBusy(true);
    try {
      const response = await invoke<any>("search_modrinth_mods", { query: modQuery.trim(), gameVersion, loader });
      const hits = response.hits || [];
      setModResults(hits as ModResult[]);
      setModsNotice(hits.length ? t(`${hits.length} projects found for Minecraft ${gameVersion} · ${loader}.`, `Найдено проектов: ${hits.length}. Совместимость фильтруется под Minecraft ${gameVersion} · ${loader}.`) : t("No results. Try a different search.", "Ничего не найдено. Попробуй другой запрос."));
    } catch (e) { setModsNotice(String(e).replace(/^Error: /, "")); setModResults([]); }
    finally { setModSearchBusy(false); }
  };

  const installMod = async (mod: ModResult) => {
    if (!selectedInstance) { setModsNotice(t("Create or select an instance first.", "Сначала создай или выбери сборку.")); setShowAddInstance(true); return; }
    const id = String(mod.project_id || "");
    if (!id) { setModsNotice(t("Modrinth did not return a project ID.", "Modrinth не вернул ID этого проекта.")); return; }
    setModInstallingId(id); setModsNotice("");
    try {
      const filename = await invoke<string>("install_modrinth_mod", { projectId: id, gameVersion: selectedInstance.versionId, loader: selectedInstance.loaderType, instanceId: selectedInstance.id });
      setModsNotice(t(`Installed: ${filename}. Restart the game if it is already running.`, `Установлен: ${filename}. Перезапусти игру, если она уже открыта.`));
      addLog(`Installed mod: ${filename}`);
      await loadInstalledMods();
    } catch (e) { setModsNotice(String(e).replace(/^Error: /, "")); }
    finally { setModInstallingId(""); }
  };

  const navItems: { id: Screen; label: string; icon: typeof Gamepad2 }[] = [
    { id: "home", label: t("Home", "Главная"), icon: Gamepad2 },
    { id: "versions", label: t("Instances", "Сборки"), icon: Layers3 },
    { id: "mods", label: t("Mods", "Моды"), icon: Blocks },
    { id: "settings", label: t("Settings", "Настройки"), icon: Settings2 },
    { id: "logs", label: t("Logs", "Журнал"), icon: FileText },
  ];

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand-row">
          <img className="brand-mark" src="/branding/optilauncher-symbol.png" alt="OptiLauncher" />
          <div className="brand-copy"><strong>Opti<span>Launcher</span></strong></div>
        </div>
        <div className="side-caption">{t("LIBRARY", "БИБЛИОТЕКА")}</div>
        <nav className="navigation">
          {navItems.map(({ id, label, icon: Icon }) => (
            <button key={id} title={label} aria-label={label} className={`nav-item ${screen === id ? "active" : ""}`} onClick={() => { setScreen(id); setError(""); }}>
              <Icon size={18} strokeWidth={1.8} /><span>{label}</span>{id === "logs" && <span className="nav-dot" />}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="side-footer"><span className="online-dot" /> {isDesktop ? t("Ready", "Готово") : t("Preview", "Предпросмотр")}<span className="version-number">v0.8.0</span></div>
        </div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <div className="breadcrumb"><img className="topbar-brand-mark" src="/branding/optilauncher-symbol.png" alt="" /><strong className="topbar-brand-name">OptiLauncher</strong><span className="crumb-slash">/</span><span>{navItems.find((n) => n.id === screen)?.label}</span></div>
          <div className="topbar-right">
            <div className={`connection-state ${isDesktop ? "connected" : "preview"}`}><span />{isDesktop ? t("Desktop app", "Приложение") : t("Preview mode", "Режим предпросмотра")}</div>
            <button className="icon-button" title={t("Refresh versions", "Обновить версии")} onClick={() => void loadManifest()} disabled={loadingManifest}><RefreshCw size={16} className={loadingManifest ? "spin" : ""} /></button>
            <button className="profile-chip" onClick={() => { setScreen("home"); setShowAddProfile(true); }}><div className="tiny-avatar">{selectedProfile?.name?.[0]?.toUpperCase() || "?"}</div><span>{selectedProfile?.name || t("No profile", "Нет профиля")}</span><ChevronDown size={14} /></button>
          </div>
        </header>

        <div className="content-scroll">
          {error && <div className="error-banner"><AlertCircle size={17} /><span>{error}</span><button onClick={() => setError("")}><X size={16} /></button></div>}
          {screen === "home" && (
            <section className="page home-page launcher-home">
              <div className="home-workspace">
                <div className="home-main-lane">
                  <section className="home-slice jump-in-section">
                    <div className="home-section-header">
                      <div><div className="eyebrow">{t("QUICK LAUNCH", "БЫСТРЫЙ ЗАПУСК")}</div><h1>{t("Jump back in", "Продолжить игру")}</h1></div>
                      <button className="primary-button compact" onClick={() => { setInstanceError(""); setShowAddInstance(true); }}><Plus size={16} /> {t("New instance", "Новая сборка")}</button>
                    </div>
                    {instances.length > 0 ? (
                      <div className="jump-list">
                        {instances.slice(0, 4).map((instance) => (
                          <article key={instance.id} className={`jump-row ${selectedInstanceId === instance.id ? "selected" : ""}`} onClick={() => selectInstance(instance)}>
                            <div className={`jump-instance-icon ${instance.loaderType}`}><Layers3 size={22} /></div>
                            <div className="jump-instance-copy"><strong>{instance.name}</strong><div className="jump-instance-meta"><span className="loader-mini-badge">{instance.loaderType.toUpperCase()}</span><span>Minecraft {instance.versionId}</span><span className="meta-dot">·</span><span>{instance.loaderType === "vanilla" ? "Vanilla" : instance.loaderType === "fabric" ? "Fabric" : "Forge"}</span></div></div>
                            {selectedInstanceId === instance.id && <span className="current-instance-pill"><span /> {t("Selected", "Выбрана")}</span>}
                            <button className="row-play-button" onClick={(event) => { event.stopPropagation(); selectInstance(instance); setScreen("home"); void launch(instance); }} title={t("Launch this instance", "Запустить эту сборку")}><Play size={15} fill="currentColor" /> {t("Play", "Играть")}</button>
                          </article>
                        ))}
                      </div>
                    ) : (
                      <div className="home-empty-state"><div className="empty-state-icon"><Layers3 size={24} /></div><div><strong>{t("No instances yet", "Пока нет сборок")}</strong><p>{t("Create an instance to choose a Minecraft version and loader.", "Создай сборку, чтобы выбрать версию Minecraft и загрузчик.")}</p></div><button className="secondary-button" onClick={() => { setInstanceError(""); setShowAddInstance(true); }}><Plus size={15} /> {t("Add instance", "Добавить сборку")}</button></div>
                    )}
                  </section>

                  <section className="home-slice library-section">
                    <div className="library-section-header">
                      <div><h2>{t("Library", "Библиотека")}</h2><p>{t("Your Minecraft setups", "Твои конфигурации Minecraft")}</p></div>
                      <div className="library-tools">
                        <label className="instance-search"><Search size={16} /><input value={homeSearch} onChange={(event) => setHomeSearch(event.target.value)} placeholder={t("Search instances", "Поиск сборок")} /></label>
                        <button className="secondary-button compact" onClick={() => setScreen("versions")}><Layers3 size={15} /> {t("Manage", "Управление")}</button>
                      </div>
                    </div>
                    {instances.filter((instance) => `${instance.name} ${instance.versionId} ${instance.loaderType}`.toLowerCase().includes(homeSearch.toLowerCase())).length > 0 ? (
                      <div className="library-instance-grid">
                        {instances.filter((instance) => `${instance.name} ${instance.versionId} ${instance.loaderType}`.toLowerCase().includes(homeSearch.toLowerCase())).map((instance) => (
                          <article key={instance.id} className={`library-instance-card ${selectedInstanceId === instance.id ? "active" : ""}`}>
                            <button className="library-card-select" onClick={() => selectInstance(instance)} title={t("Select instance", "Выбрать сборку")}>
                              <div className="library-card-art"><div className={`library-cube ${instance.loaderType}`}><Layers3 size={25} /></div><span className={`instance-loader-pill ${instance.loaderType}`}>{instance.loaderType.toUpperCase()}</span></div>
                              <div className="library-card-copy"><strong>{instance.name}</strong><span>Minecraft {instance.versionId}</span><small>{instance.loaderType === "vanilla" ? "Vanilla" : instance.loaderType === "fabric" ? "Fabric Loader" : "Forge"}</small></div>
                            </button>
                            <div className="library-card-actions"><button className="card-open-button" onClick={() => selectInstance(instance)}>{selectedInstanceId === instance.id ? <><Check size={14} /> {t("Selected", "Выбрана")}</> : t("Select", "Выбрать")}</button><button className="card-play-button" onClick={() => { selectInstance(instance); void launch(instance); }} title={t("Launch this instance", "Запустить эту сборку")}><Play size={15} fill="currentColor" /> {t("Play", "Играть")}</button></div>
                          </article>
                        ))}
                      </div>
                    ) : (
                      <div className="library-empty"><Search size={20} /><span>{instances.length ? t("No instances match your search.", "Нет сборок по этому запросу.") : t("Your instances will appear here.", "Твои сборки появятся здесь.")}</span></div>
                    )}
                  </section>

                  {launching && <div className="progress-panel"><div className="progress-header"><div><LoaderCircle size={17} className="spin" /><strong>{phase || t("Preparing game", "Подготовка игры")}</strong></div><span>{progress.total ? `${progressPct}%` : "…"}</span></div><div className="progress-track"><span style={{ width: `${progressPct}%` }} /></div><div className="progress-meta"><span>{progress.label || t("Preparing files", "Подготавливаем файлы")}</span><span>{progress.done}/{progress.total || "—"} {t("files", "файлов")}</span></div></div>}
                </div>

                <aside className="home-right-rail">
                  <section className="rail-card playing-as-card"><div className="rail-eyebrow">{t("PLAYING AS", "ИГРОК")}</div><div className="rail-profile"><div className="rail-avatar">{selectedProfile?.name?.[0]?.toUpperCase() || <UserRound size={18} />}</div><div className="rail-profile-copy"><strong>{selectedProfile?.name || t("No profile", "Нет профиля")}</strong><small>{selectedProfile?.kind === "microsoft" ? "Microsoft account" : selectedProfile ? t("Local profile", "Локальный профиль") : t("Sign in to continue", "Войди, чтобы продолжить")}</small></div></div><button className="rail-action" onClick={() => setShowAddProfile(true)}>{selectedProfile ? t("Switch profile", "Сменить профиль") : t("Add profile", "Добавить профиль")} <ExternalLink size={13} /></button></section>
                  <section className="rail-card selected-instance-rail"><div className="rail-card-heading"><span className="rail-eyebrow">{t("CURRENT INSTANCE", "ТЕКУЩАЯ СБОРКА")}</span><button className="rail-icon-action" title={t("Manage instances", "Управлять сборками")} onClick={() => setScreen("versions")}><ExternalLink size={14} /></button></div>{selectedInstance ? <><h3>{selectedInstance.name}</h3><div className="rail-version-line">Minecraft {selectedInstance.versionId}</div><div className="rail-meta-pills"><span>{selectedInstance.loaderType.toUpperCase()}</span><span>{t("Java Edition", "Java Edition")}</span></div><button className="rail-action" onClick={() => setScreen("versions")}>{t("Instance settings", "Настройки сборки")} <ExternalLink size={13} /></button></> : <><p>{t("Choose or create an instance to get started.", "Выбери или создай сборку, чтобы начать.")}</p><button className="rail-action" onClick={() => { setInstanceError(""); setShowAddInstance(true); }}>{t("Create instance", "Создать сборку")} <Plus size={14} /></button></>}</section>
                  <section className="rail-card mods-rail-card"><div className="mods-rail-icon"><Blocks size={18} /></div><div className="rail-eyebrow">{t("MOD LIBRARY", "БИБЛИОТЕКА МОДОВ")}</div><h3>{t("Make it yours", "Настрой игру под себя")}</h3><p>{t("Find mods for your selected Minecraft version and loader.", "Находи моды под выбранную версию Minecraft и загрузчик.")}</p><button className="rail-action rail-action-primary" onClick={() => setScreen("mods")}>{t("Browse mods", "Каталог модов")} <ExternalLink size={13} /></button></section>
                </aside>
              </div>
            </section>
          )}

          {screen === "versions" && (
            <section className="page instances-page">
              <div className="page-title-row"><div><div className="eyebrow">INSTANCE MANAGER</div><h1>{t("My", "Мои")} <span>{t("Instances", "сборки")}</span></h1><p className="page-description">{t("Each instance keeps its own Minecraft version, loader and game folder.", "Каждая сборка хранит собственную версию Minecraft, загрузчик и папку игры.")}</p></div><button className="primary-button compact" onClick={() => { setInstanceError(""); setShowAddInstance(true); }}><Plus size={16} /> {t("Add instance", "Добавить сборку")}</button></div>
              {instances.length ? <div className="instances-grid">{instances.map((instance) => <article key={instance.id} className={`instance-card ${selectedInstanceId === instance.id ? "active" : ""}`}>
                <div className="instance-card-banner"><div className="instance-cube"><Layers3 size={23} /></div><span className={`instance-loader-pill ${instance.loaderType}`}>{instance.loaderType.toUpperCase()}</span>{selectedInstanceId === instance.id && <span className="instance-active-pill"><Check size={12} /> {t("ACTIVE", "АКТИВНА")}</span>}</div>
                <div className="instance-card-body"><h3>{instance.name}</h3><p>Minecraft Java Edition</p><div className="instance-card-meta"><span><Layers3 size={14} /> {instance.versionId}</span><span><Blocks size={14} /> {instance.loaderType === "vanilla" ? "Vanilla" : instance.loaderType === "fabric" ? "Fabric Loader" : "Forge"}</span></div>
                  <div className="instance-card-actions"><button className={`secondary-button ${selectedInstanceId === instance.id ? "instance-selected-button" : ""}`} onClick={() => selectInstance(instance)}>{selectedInstanceId === instance.id ? <><Check size={15} /> {t("Selected", "Выбрана")}</> : t("Select", "Выбрать")} </button><button className="primary-button" onClick={() => { selectInstance(instance); setScreen("home"); void launch(instance); }}><Play size={14} fill="currentColor" /> {t("Play", "Играть")}</button><button className="icon-button instance-remove-button" title={t("Remove instance from list", "Убрать сборку из списка")} onClick={() => void removeInstance(instance)}><Trash2 size={15} /></button></div>
                </div>
              </article>)}</div> : <div className="instances-empty"><div className="instances-empty-icon"><Layers3 size={30} /></div><h3>{t("No instances yet", "Пока нет сборок")}</h3><p>{t("Create your first setup: choose a Minecraft version, Vanilla / Fabric / Forge and give it a name.", "Создай первую: выбери версию Minecraft, Vanilla / Fabric / Forge и задай собственное название.")}</p><button className="primary-button" onClick={() => { setInstanceError(""); setShowAddInstance(true); }}><Plus size={16} /> {t("Add your first instance", "Добавить первую сборку")}</button></div>}
              <div className="note-card instances-footnote"><Info size={15} /><span>{t("Instances are kept separate. Removing one from the list does not delete game files or worlds from disk.", "Сборки хранятся отдельно друг от друга. Удаление из списка не стирает игровые файлы и миры с диска.")}</span></div>
            </section>
          )}

          {screen === "mods" && (
            <section className="page mods-page">
              <div className="page-title-row"><div><div className="eyebrow">MOD LIBRARY</div><h1>{t("Mods", "Моды")} <span>{t("and add-ons", "и дополнения")}</span></h1><p className="page-description">{t("Find Modrinth mods for your selected Minecraft version and loader.", "Находи моды на Modrinth под выбранную версию и загрузчик.")}</p></div><div className="mods-loader-badge"><Blocks size={16} /> {selectedInstance ? `${selectedInstance.loaderType.toUpperCase()} · ${selectedInstance.versionId}` : t("No instance selected", "Сборка не выбрана")}</div></div>
              <div className="modrinth-source-card"><div className="modrinth-source-mark">M</div><div><strong>{t("Modrinth catalog", "Каталог Modrinth")}</strong><p>{t("Official API · search and downloads without an API key", "Официальный API · поиск и загрузка без API-ключа")}</p></div><a href="https://modrinth.com/mods" target="_blank" rel="noreferrer">{t("Open catalog", "Открыть каталог")} <ExternalLink size={13} /></a></div>
              <div className="mods-search-row"><div className="search-box mods-search-box"><Search size={18} /><input value={modQuery} onChange={(e) => setModQuery(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") void searchMods(); }} placeholder={t("Try Sodium, JEI, minimap…", "Например: Sodium, JEI, minimap…")} /></div><button className="primary-button" onClick={() => void searchMods()} disabled={modSearchBusy}>{modSearchBusy ? <LoaderCircle size={16} className="spin" /> : <Search size={16} />} {t("Search mods", "Найти моды")}</button></div>
              {modsNotice && <div className={`mods-notice ${(modsNotice.startsWith("Installed") || modsNotice.startsWith("Установлен")) ? "success" : ""}`}><Info size={15} /><span>{modsNotice}</span></div>}
              {!selectedInstance && <div className="note-card mods-warning"><Info size={16} /><span>{t("Create or select an instance first.", "Сначала создай или выбери сборку.")}</span><button className="text-button" onClick={() => setShowAddInstance(true)}>{t("Add instance", "Добавить сборку")} <Plus size={14} /></button></div>}{selectedInstance?.loaderType === "vanilla" && <div className="note-card mods-warning"><Info size={16} /><span>{t("Create a Fabric or Forge instance to install mods.", "Для установки модов создай сборку на Fabric или Forge.")}</span></div>}
              <div className="mod-results-grid">{modResults.map((mod) => {
                const id = String(mod.project_id || "");
                const title = mod.title || mod.slug || t("Untitled project", "Без названия");
                const author = mod.author || t("Unknown author", "неизвестного автора");
                return <article className="mod-result-card" key={id}><div className="mod-card-heading">{mod.icon_url ? <img src={mod.icon_url} alt="" /> : <div className="mod-placeholder-icon"><Blocks size={21} /></div>}<div><h3>{title}</h3><small>{t("by", "от")} {author}</small></div></div><p>{mod.description || t("No project description provided.", "Описание проекта не предоставлено.")}</p><div className="mod-card-meta"><span><Download size={13} /> {Intl.NumberFormat(language === "ru" ? "ru-RU" : "en-US", { notation: "compact" }).format(mod.downloads || 0)}</span><span>Modrinth</span></div><div className="mod-card-actions"><button className="primary-button" disabled={!selectedInstance || selectedInstance.loaderType === "vanilla" || !!modInstallingId} onClick={() => void installMod(mod)}>{modInstallingId === id ? <LoaderCircle size={15} className="spin" /> : <Download size={15} />} {t("Install", "Установить")}</button><button className="icon-button" title={t("Open project page", "Открыть страницу проекта")} onClick={() => { window.open(`https://modrinth.com/mod/${mod.slug || id}`, "_blank", "noopener,noreferrer"); }}><ExternalLink size={15} /></button></div></article>;
              })}</div>
              {modResults.length === 0 && <div className="mods-empty"><div><Blocks size={25} /></div><h3>{t("Find a mod for your instance", "Найди мод для своей сборки")}</h3><p>{t("Results are filtered for the selected Minecraft version and loader.", "Результаты отфильтруются по выбранной версии Minecraft и загрузчику.")}</p></div>}
              <div className="installed-mods-panel"><div className="installed-mods-header"><div><h3>{t("Installed mods", "Установленные моды")}</h3><p>{t("Instance folder", "Папка сборки")} · {selectedInstance?.name || t("no instance selected", "сборка не выбрана")}</p></div><span>{installedMods.length} {t("files", "файлов")}</span></div>{installedMods.length ? <div className="installed-mods-list">{installedMods.map((m) => <div key={m.fileName}><Blocks size={15} /><span>{m.fileName}</span><Check size={14} /></div>)}</div> : <p className="installed-empty">{t("Nothing here yet. Installed .jar files will appear here.", "Пока пусто. Установленные .jar-файлы появятся здесь.")}</p>}</div>
              <div className="note-card"><Info size={15} /><span>{t("OptiLauncher downloads the selected file into the instance folder. Some mods need extra dependencies, such as Fabric API, which must be installed separately.", "OptiLauncher скачивает выбранный файл в папку профиля. Некоторые моды требуют дополнительных зависимостей, например Fabric API; их нужно установить отдельно.")}</span></div>
            </section>
          )}

          {screen === "settings" && (
            <section className="page settings-page">
              <div className="page-title-row"><div><div className="eyebrow">PREFERENCES</div><h1>{t("Launcher", "Настройки")} <span>{t("Settings", "лаунчера")}</span></h1><p className="page-description">{t("Adjust Minecraft to your computer.", "Подстрой запуск Minecraft под свой компьютер.")}</p></div><div className="page-icon-tile"><Settings2 size={22} /></div></div>
              <div className="settings-grid">
                <div className="settings-card language-preference-card"><div className="settings-card-title"><div className="setting-glyph green"><Info size={18} /></div><div><h3>{t("Language", "Язык")}</h3><p>{t("Choose the launcher interface language.", "Выбери язык интерфейса лаунчера.")}</p></div></div><label className="form-field language-select-field"><span>{t("Interface language", "Язык интерфейса")}</span><select value={language} onChange={(event) => updateLanguage(event.target.value as "en" | "ru")}><option value="en">English</option><option value="ru">Русский</option></select></label><small className="field-help">{t("Changes are saved automatically.", "Изменения сохраняются автоматически.")}</small></div>
                <div className="settings-card"><div className="settings-card-title"><div className="setting-glyph purple"><MemoryStick size={18} /></div><div><h3>{t("Java memory", "Память Java")}</h3><p>{t("Memory available to the game", "Размер памяти, доступной игре")}</p></div></div><div className="setting-control"><div className="control-label"><span>{t("Maximum memory", "Максимальная память")}</span><strong>{settings.ramGb} GB</strong></div><input className="range-control" type="range" min="2" max="16" step="1" value={settings.ramGb} onChange={(e) => setSettings((s) => ({ ...s, ramGb: Number(e.target.value), minRamGb: Math.min(s.minRamGb, Number(e.target.value) - 1) }))} /><div className="range-markers"><span>2 GB</span><span>8 GB</span><span>16 GB</span></div></div><div className="setting-control"><div className="control-label"><span>{t("Initial memory", "Стартовая память")}</span><strong>{settings.minRamGb} GB</strong></div><input className="range-control" type="range" min="1" max={Math.max(1, settings.ramGb - 1)} step="1" value={settings.minRamGb} onChange={(e) => setSettings((s) => ({ ...s, minRamGb: Number(e.target.value) }))} /><div className="range-markers"><span>1 GB</span><span>{t("2 GB recommended", "Рекомендуется 2 GB")}</span></div></div><div className="hint-card"><Info size={15} /><span>{t("Minecraft usually works well with 4–6 GB. Do not allocate all your computer’s RAM to the game.", "Обычно Minecraft хватает 4–6 GB. Не выделяй игре всю оперативную память компьютера.")}</span></div></div>
                <div className="settings-card"><div className="settings-card-title"><div className="setting-glyph blue"><Laptop size={18} /></div><div><h3>{t("Game window", "Окно игры")}</h3><p>{t("Initial Minecraft resolution", "Стартовое разрешение Minecraft")}</p></div></div><div className="form-grid"><label className="form-field"><span>{t("Width", "Ширина")}</span><select value={settings.resolutionWidth} onChange={(e) => setSettings((s) => ({ ...s, resolutionWidth: Number(e.target.value) }))}>{[854, 1024, 1280, 1366, 1600, 1920, 2560].map((n) => <option key={n} value={n}>{n}px</option>)}</select></label><label className="form-field"><span>{t("Height", "Высота")}</span><select value={settings.resolutionHeight} onChange={(e) => setSettings((s) => ({ ...s, resolutionHeight: Number(e.target.value) }))}>{[480, 600, 720, 768, 900, 1080, 1440].map((n) => <option key={n} value={n}>{n}px</option>)}</select></label></div><div className="setting-control"><div className="control-label"><span>{t("Java Runtime path", "Путь к Java Runtime")}</span><span className="optional-label">{t("Optional", "Необязательно")}</span></div><input className="text-input" value={settings.javaPath} onChange={(e) => setSettings((s) => ({ ...s, javaPath: e.target.value }))} placeholder={navigator.platform.toLowerCase().includes("win") ? "C:\\Program Files\\Java\\bin\\java.exe" : "/usr/bin/java"} /><small className="field-help">{t("Leave empty to let the launcher find or download a compatible Java runtime.", "Пустое поле — лаунчер попробует найти или скачать подходящую Java.")}</small></div></div>
                <div className="settings-card full-settings-card"><div className="settings-card-title"><div className="setting-glyph green"><ShieldCheck size={18} /></div><div><h3>{t("Application data", "Данные приложения")}</h3><p>{t("Where launcher files are stored", "Информация о том, где хранятся файлы")}</p></div></div><div className="storage-row"><div className="storage-leading"><div className="storage-icon"><HardDrive size={18} /></div><div><strong>OptiLauncher folder</strong><small>{t("Profiles, settings, libraries, assets and Java", "Профили, настройки, библиотеки, ресурсы и Java")}</small></div></div><span className="storage-location">AppData / OptiLauncher</span></div><div className="storage-row"><div className="storage-leading"><div className="storage-icon"><ShieldCheck size={18} /></div><div><strong>{t("Authentication", "Аутентификация")}</strong><small>{t("Secure sign-in · refresh token stored by the OS", "Защищённый вход · токен обновления хранится в системе")}</small></div></div><span className="muted-value">{profiles.some((p) => p.kind === "microsoft") ? t("Microsoft: connected", "Microsoft: подключён") : t("Microsoft: not connected", "Microsoft: не подключён")}</span></div><div className="auth-info-strip"><ShieldCheck size={16} /><div><strong>{t("Microsoft sign-in", "Вход Microsoft")}</strong><small>{t("Click Sign in to open the official Microsoft page. The launcher checks Minecraft Java access after authentication.", "Нажми «Войти»: откроется обычная страница Microsoft, после входа лаунчер сам проверит доступ к Minecraft Java Edition.")}</small></div></div></div></div>
              <div className="settings-actions"><span className="settings-note"><Info size={14} /> {t("Changes apply the next time you launch the game.", "Изменения применятся к следующему запуску игры.")}</span><button className="primary-button" onClick={() => void saveSettings()}>{settingsSaved ? <Check size={17} /> : <Check size={17} />}{settingsSaved ? t("Saved", "Сохранено") : t("Save settings", "Сохранить настройки")}</button></div>
            </section>
          )}

          {screen === "logs" && (
            <section className="page">
              <div className="page-title-row"><div><div className="eyebrow">DIAGNOSTICS</div><h1>{t("Activity", "Журнал")} <span>{t("Log", "событий")}</span></h1><p className="page-description">{t("Launcher events and Minecraft process output.", "События лаунчера и вывод процесса Minecraft.")}</p></div><button className="secondary-button compact" onClick={() => { setLogs([]); setError(""); }}><Trash2 size={15} /> {t("Clear", "Очистить")}</button></div>
              <div className="logs-toolbar"><div><span className="log-led" /> LIVE OUTPUT <span className="logs-count">{logs.length} {t("entries", "записей")}</span></div><button onClick={() => { void navigator.clipboard?.writeText(logs.join("\n")); }}><FileText size={14} /> {t("Copy text", "Копировать текст")}</button></div><div className="terminal"><div className="terminal-top"><div className="terminal-lights"><i /><i /><i /></div><span>optilauncher — console</span><Activity size={14} /></div><div className="terminal-content">{logs.length === 0 ? <div className="terminal-empty">{t("Log cleared. New events will appear here.", "Журнал очищен. Новые события появятся здесь.")}</div> : logs.map((line, i) => <div className="log-line" key={`${i}-${line}`}><span className="log-index">{String(i + 1).padStart(3, "0")}</span><span className={line.toLowerCase().includes("ошибка") || line.toLowerCase().includes("error") ? "log-error" : line.includes("успеш") || line.includes("готово") ? "log-success" : ""}>{line}</span></div>)}</div></div><div className="logs-disclaimer"><Info size={15} /><span>{t("Logs may include file names and game messages. Microsoft refresh tokens are stored by the OS; access tokens are not written to logs.", "Логи могут содержать имена файлов и сообщения игры. Refresh-токен Microsoft хранится в системном хранилище; access-токены не записываются в логи.")}</span></div>
            </section>
          )}

        </div>
      </main>

      {showAddInstance && <div className="modal-backdrop instance-modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) setShowAddInstance(false); }}><div className="modal-card instance-modal">
        <button className="modal-close" onClick={() => setShowAddInstance(false)}><X size={18} /></button>
        <div className="modal-icon"><Layers3 size={22} /></div><div className="eyebrow">{t("NEW INSTANCE", "НОВАЯ СБОРКА")}</div><h2>{t("Add instance", "Добавить сборку")}</h2><p>{t("Create a separate Minecraft setup with its own settings, mods and game files.", "Создай отдельный экземпляр Minecraft. У каждой сборки будут свои настройки, моды и игровые файлы.")}</p>
        {instanceError && <div className="profile-error"><AlertCircle size={15} /><span>{instanceError}</span></div>}
        <label className="form-field"><span>{t("Instance name", "Название сборки")}</span><input className="text-input" autoFocus value={instanceName} maxLength={32} onChange={(e) => setInstanceName(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") void createInstance(); }} placeholder={t("e.g. Survival 1.21", "Например, Survival 1.21")} /></label>
        <label className="form-field"><span>{t("Minecraft version", "Версия Minecraft")}</span><select className="text-input instance-version-select" value={instanceVersion} onChange={(e) => setInstanceVersion(e.target.value)}>{versions.filter((v) => v.type === "release").map((v) => <option key={v.id} value={v.id}>{v.id} · Release</option>)}{versions.filter((v) => v.type !== "release").slice(0, 40).map((v) => <option key={v.id} value={v.id}>{v.id} · {v.type}</option>)}</select></label>
        <div className="form-field"><span>{t("Loader", "Тип сборки")}</span><div className="loader-choice-grid">
          {[{id:"vanilla",name:"Vanilla",description:t("Unmodified Minecraft","Обычная игра"),symbol:"V"},{id:"fabric",name:"Fabric",description:t("Lightweight mod loader","Лёгкий модлоадер"),symbol:"F"},{id:"forge",name:"Forge",description:t("Large mod ecosystem","Широкая экосистема модов"),symbol:"F"}].map((loader) => <button type="button" key={loader.id} className={`loader-choice ${instanceLoader === loader.id ? "selected" : ""}`} onClick={() => setInstanceLoader(loader.id)}><span className={`loader-choice-symbol ${loader.id}`}>{loader.symbol}</span><strong>{loader.name}</strong><small>{loader.description}</small>{instanceLoader === loader.id && <Check size={15} className="loader-choice-check" />}</button>)}
        </div></div>
        <div className="instance-create-summary"><div><span>{t("INSTANCE NAME", "НАЗВАНИЕ")}</span><strong>{instanceName.trim() || t("New instance", "Новая сборка")}</strong></div><div><span>{t("CONFIGURATION", "КОНФИГУРАЦИЯ")}</span><strong>{instanceVersion || t("No version selected", "Версия не выбрана")} · {instanceLoader.toUpperCase()}</strong></div></div>
        <button className="primary-button modal-submit" onClick={() => void createInstance()} disabled={creatingInstance || !instanceName.trim() || !instanceVersion}>{creatingInstance ? <LoaderCircle size={16} className="spin" /> : <Plus size={17} />}{creatingInstance ? t("Creating instance…", "Создаём сборку…") : t("Create instance", "Создать сборку")}</button>
      </div></div>}

      {showAddProfile && <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) setShowAddProfile(false); }}><div className="modal-card profile-modal"><button className="modal-close" onClick={() => setShowAddProfile(false)}><X size={18} /></button><div className="modal-icon"><Users size={22} /></div><div className="eyebrow">{t("PLAYER PROFILE", "ПРОФИЛЬ ИГРОКА")}</div><h2>{t("Add profile", "Добавить профиль")}</h2><p>{t("Sign in with Microsoft or create a local profile.", "Подключи аккаунт Microsoft для игры с лицензией или создай локальный профиль.")}</p><div className="microsoft-login-box"><div className="microsoft-logo"><span>Microsoft</span></div><div className="microsoft-login-copy"><strong>{t("Microsoft sign-in", "Вход Microsoft")}</strong><small>{t("Sign-in opens in your browser and the profile is checked automatically.", "Вход откроется в браузере, профиль проверится автоматически")}</small></div><button className="secondary-button" onClick={() => void microsoftLogin()} disabled={microsoftLoginBusy}>{microsoftLoginBusy ? <LoaderCircle size={15} className="spin" /> : <ExternalLink size={15} />}{microsoftLoginBusy ? t("Waiting for sign-in…", "Ожидаем вход…") : t("Sign in", "Войти")}</button></div>{microsoftLoginBusy && <div className="login-progress-note"><LoaderCircle size={16} className="spin" /><span>{t("Complete sign-in in your browser. Your account will appear here automatically.", "Заверши вход в браузере. После проверки аккаунт появится здесь автоматически.")}</span></div>}{profileError && <div className="profile-error"><AlertCircle size={15} /><span>{profileError}</span></div>}<div className="modal-divider-label"><span>{t("OR USE A LOCAL PROFILE", "ИЛИ ЛОКАЛЬНЫЙ ПРОФИЛЬ")}</span></div><label className="form-field"><span>{t("Player name", "Ник игрока")}</span><input className="text-input" autoFocus value={profileName} maxLength={16} onChange={(e) => setProfileName(e.target.value.replace(/[^A-Za-z0-9_]/g, ""))} onKeyDown={(e) => { if (e.key === "Enter") void createProfile(); }} placeholder={t("YourNickname", "YourNickname")} /></label><div className="modal-helper"><ShieldCheck size={15} /> {t("3–16 letters, numbers or underscores.", "3–16 латинских букв, цифр или подчёркиваний.")}</div><button className="primary-button modal-submit" onClick={() => void createProfile()} disabled={profileName.length < 3}><Plus size={17} /> {t("Create profile", "Создать профиль")}</button>
          {profiles.length > 0 && <div className="existing-profiles"><div className="profile-list-title">{t("SAVED PROFILES", "СОХРАНЁННЫЕ ПРОФИЛИ")}</div>{profiles.map((p) => <div className={`profile-option ${selectedProfileId === p.id ? "selected" : ""}`} key={p.id} onClick={() => { setSelectedProfileId(p.id); setShowAddProfile(false); }}><div className="tiny-avatar">{p.name[0].toUpperCase()}</div><div><strong>{p.name}</strong><small>{p.kind === "microsoft" ? t("Microsoft · Minecraft Java", "Microsoft · Minecraft Java") : t("Local profile", "Локальный профиль")}</small></div>{selectedProfileId === p.id && <Check size={16} />}{profiles.length > 1 && <button className="remove-profile" title={t("Remove profile", "Удалить профиль")} onClick={(e) => { e.stopPropagation(); void removeProfile(p); }}><Trash2 size={14} /></button>}</div>)}</div>}
        </div></div>}
    </div>
  );
}

export default App;
